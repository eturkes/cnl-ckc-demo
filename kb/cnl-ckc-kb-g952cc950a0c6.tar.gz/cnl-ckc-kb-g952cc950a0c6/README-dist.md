# cnl-ckc knowledge base export

This archive is a BagIt 1.0 bag. It holds the compiled clinical-guideline knowledge base from the cnl-ckc repository. The archive name and the `meta head` row in `release-manifest.tsv` give the source commit.

## Verification

Run `sha256sum -c manifest-sha256.txt tagmanifest-sha256.txt` from this directory. Each line must report OK.

## Contents

- cdc-2022-opioid (redistributable): 337 documents.

## Review status

Each shipped document has a label row in release-manifest.tsv.

- approved: 0 documents.
- rejected: 0 documents.
- contested: 0 documents.
- stale: 0 documents.
- unreviewed: 337 documents.

## Rights

- cdc-2022-opioid (redistributable): "All material in the MMWR Series is in the public domain and may be used and reprinted without special permission; citation as to source, however, is appreciated." Source: https://www.cdc.gov/mmwr/about.html, retrieved 2026-07-22. CDC statement quoted in the guideline README, Rights and attribution section. CDC does not endorse this project.

## Replay

These commands run in the source repository at the commit that this archive names.

- compile: python3 -P tools/goal.py compile <guideline-id>
- check: python3 -P tools/goal.py check
- load: swipl -q -s data/guidelines/<guideline-id>/pl/<docid>.pl

## Compiled Prolog schema (v1)

Status: **frozen**. Every compiled document emits
`guideline_schema_version(1).`. The predicate set below is the public
ABI: an extension requires a version bump. v1 is the compiler's
sole schema. A future version takes a new explicit invocation argument;
the compiler never infers a version from content. Authored questions
reject in document compiles; the separate question mode below compiles
one question into a query projection over the same vocabulary.

Sentences project onto a closed reserved vocabulary. Source words —
nouns, verbs, adjectives, prepositions — stay opaque data atoms and
never become predicate functors. The schema is therefore language- and
domain-neutral:

| Predicate | Meaning |
| --- | --- |
| `guideline_schema_version(Version)` | schema version of this document (`1`) |
| `guideline_document(DocId, ace_sha256(H), ulex(none \| sha256(H)))` | document record + source digests |
| `guideline_entity(Context, Ref, Noun, Class)` | an entity referent and its noun/class |
| `guideline_cardinality(Context, Ref, Unit, Comparison, Count)` | that referent's quantity payload, verbatim |
| `guideline_event(Context, EventRef, Lemma)` | an event referent and its verb |
| `guideline_arg(Context, EventRef, Position, Ref)` | participant at `Position` (1-based, DRS order) |
| `guideline_pp(Context, EventRef, Preposition, Ref)` | prepositional attachment on the event |
| `guideline_property(Context, PropertyRef, Lemma, Polarity)` | adjectival property (`pos` in v1) |
| `guideline_operator(OuterContext, InnerContext, Operator)` | reified modal/negation wrapper: `InnerContext`'s content stands under `Operator` relative to `OuterContext` |

`Comparison` is exactly one of `eq`, `geq`, `greater`, `leq`, `less`,
`exactly`, `na`. The compiler copies units and counts through as data.
It performs no arithmetic, no unit conversion, no counting, and no
modal inference: a cardinality clause records what the sentence said,
nothing more.

Every one of those values is reachable, but not from every position. An
upper-bounding determiner (`at most n`, `exactly n`, `less than n`) is
scoped. At the root of an asserted sentence, ACE groups the conditions
that the determiner binds into a condition list. v1 has no construct
for that scope, so the document rejects with
`unsupported, root_condition([…])` rather than flatten an upper bound
into an existential claim; `tests/red/unsupported--v1-root-at-most.ace`
pins the detail. The same phrase inside a rule or an operator box
carries no group and compiles, emitting `leq`, `exactly`, or `less`
under that context. `at least n` and `more than n` bound below, are
never grouped, and compile in any position.

`Context` is `actual` for asserted content, or a generated operator
context:

```
Context      ::= actual | '$guideline_id'(context, DocId, S, box(B), Deps)
Operator     ::= should | must | can | may | '-'
OperatorEdge ::= guideline_operator(OuterContext, InnerContext, Operator)
```

The compiler reifies modality and classical negation as data, never as
inference. Each DRS operator box becomes one `guideline_operator/3`
edge from its enclosing context to a fresh box context. The compiler
emits that edge before the box's payload clauses, which carry the box
context in their own `Context` argument. The operator atoms are the DRS
functors themselves (`-` is classical negation), so a non-English
frontend produces the same tags. ¬SHOULD(P) and SHOULD(¬P) stay
structurally distinct, and the compiler performs no deontic, modal, or
classical inference. `box(B)` numbers a sentence's operator boxes in
whole-sentence preorder. `Deps` follows the Skolem dependency rule:
empty for root facts, the antecedent's top-level referents for
consequent boxes. A consequent operator context is therefore a
per-antecedent-solution witness. In rule bodies, an operator box binds
an existential context variable — `guideline_operator(Outer, V, Op)`
plus payload goals that share `V`. Matching is Horn-monotone structure
satisfaction over whatever documents are loaded. Extra clauses under a
producer context therefore never block a match, and two body boxes may
bind one producer context whose payload satisfies both. A consumer that
wants unwrapped content only keeps `Context = actual`. An
operator-aware consumer adds one recursive walk over
`guideline_operator/3` edges (a `ctx_desc/2` descendant relation) to
collect content under a modality.

Negation-as-failure ("does not provably …") in a rule antecedent
compiles to an executable `\+ (…)` over the box's goals. Its scope is
the loaded aggregate: the engine evaluates `\+` against whatever
document set is co-loaded, so absence is corpus-relative, never
document-local. Negation-as-failure in a consequent or a root fact
rejects; assertion-by-absence is meaningless.

A universally quantified sentence becomes one Horn clause per
consequent condition. All clauses of a rule variant share one identical
rendered body. A nested `if … then if … then …` consequent curries into
one rule whose antecedent concatenates the nested domains. An
antecedent that contains one disjunction splits into two variants whose
bodies are the shared conditions plus that arm. The bundle keeps one
sentence comment, with variant-1 clauses and then variant-2 clauses,
contiguous. The compiler Skolemizes a referent introduced only in the
consequent to
`'$guideline_id'(product, DocId, SentenceId, ref(N), Deps)`. `Deps` is
the concatenation of every curried antecedent segment's top-level
referents in DRS order; a split variant appends its arm's top-level
referents. A referent introduced inside an operator or
negation-as-failure (NAF) box contributes nothing to any `Deps` list:
it is consequent-inaccessible and stays a box-local existential. `N` is
the referent's first-occurrence position in the sentence's unsplit
expansion. Both variants of a split mint the same `ref(N)`,
distinguished by `Deps`. The constructor's first argument names the
term's role: `context` for an operator box, `product` for a consequent
referent, `witness` for a proof instance (below). All three name the
compiler's own chosen stand-in — never a source-given name, real-world
identity, or uniqueness claim. Because facts and derived heads share
one vocabulary, a rule body consumes another document's facts or heads
by ordinary resolution.

Every v1 document opens with the same declaration block: `multifile`
and `discontiguous` for all nine indicators, whether or not it
populates them. After the block come `guideline_schema_version(1).`,
the document record, and then, per sentence, a
`% S<n>: <verbatim sentence>` comment with that sentence's contiguous
clauses in deterministic order. Any subset of v1 documents therefore
co-loads into one engine in any order with no warnings. Names that
begin with `guideline_` and the identity constructor `'$guideline_id'`
are reserved: a colliding name rejects the document rather than
silently shadow schema vocabulary. The compiler scans both the parsed
sentence and every lexicon entry — used or not — for one.
`guideline_part/3` is reserved for a later unit and stays unemitted in
v1. Shapes still outside the schema (group coordination, disjunctive
consequents, rules scoped inside an operator) reject with a canonical
`ace_to_pl_error(unsupported, …)` line. A question inside a document
rejects with `question_not_supported(Form, S)`, where `Form` is
`wh(Tag)`, `universal`, or `yesno`.

Compilation is checked, not asserted. Every v1 compile derives the
document's proof obligations and discharges them before it emits
anything. Appending `proof` to the invocation prints the derivation
payload in place of the document. The payload is one
`'$guideline_proof'(DocId, S, variant(K), witness(Facts), prove(Heads))`
term per fact group and per rule variant. `Facts` is that group's own
positive body under a witness substitution; NAF boxes contribute
nothing, by design. `Heads` is that group's clause heads under the same
substitution. The compiler asserts each witness ahead of the document's
rule clauses, proves every head under bounded search, then retracts.
The bounds are depth 4000 inside 1,000,000 inferences; a search that
exceeds either bound counts as underivable. A group whose heads stay
non-ground under its own witness rejects with
`proof, nonground_obligation(…)`. A group whose heads do not derive
rejects with `proof, underivable_obligation(…)`. Both exit 1. Witness
terms carry the document's own document, sentence, and variant
coordinates, so no foreign clause can discharge an obligation. Success
is modus ponens over that sentence's own projection.

`aggregate-check <manifest>` replays those obligations across a
composition. The manifest is strict: one `<compiled-pl>` TAB
`<payload>` row per document, with the final newline required. A 0-byte
file means the empty composition. The compiler loads every document
into one engine; any load diagnostic is a failure. It checks that the
distinct `guideline_document/3` records equal the manifest row count
and that the loaded schema-version set is exactly `[1]`. It then
re-derives every obligation against the whole batch. Co-loading can
therefore neither break a document's derivations nor silently repair
them, and the engine evaluates negation-as-failure against the
composition it will actually run in. The check reports
`ace_to_pl aggregate ok <N> documents <G> obligations`.

`recursion-check <manifest>` loads that same composition and ignores
the payload column. It proves that no clause head unifies with its own
leftmost body goal, renaming the goal apart first the way SLD renames a
clause. A match rejects as `proof, left_recursive(Site, Name, Arity)`,
where `Site` is the offending clause's own `sentence(DocId, S)` when it
carries one. The scan is structural, so its verdict is load-order
independent. It reports
`ace_to_pl recursion ok <N> documents <M> rule clauses`; the count
names what it read.

Payloads are evidence, not authority: the gate checks `<G>` against the
composition rather than take it from the payload stream. Before the
replay proves any head, four conditions must hold:

- The obligation set must cover exactly the sentence identities that
  the loaded documents themselves carry (`missing_obligation` /
  `extra_obligation`).
- Its `(document, sentence, variant)` keys must be unique
  (`duplicate_obligation`), with variants numbered `1..K` per sentence
  (`variant_sequence`).
- No group may prove an empty head list (`empty_obligation`).
- A nonempty payload file must end in the newline that its last term
  wrote (`check_load, payload_bytes`).

An emptied, truncated, repeated, or misattributed payload therefore
fails the replay instead of shrinking it. Manifest rows bind product to
payload for provenance; replay soundness rests on that composition-wide
coverage. One residue is open by construction: dropping the LAST
variant of a multi-variant sentence leaves coverage complete and
variant numbering contiguous. The frozen ABI carries no per-sentence
variant count to check it against.

Compiled documents are a definite-clause program, so termination is the
consuming engine's responsibility, not a property that the schema can
promise. Facts and derived heads share one vocabulary by design; that
is what lets one document's rules consume another's clauses. The same
sharing lets an authored rule whose consequent entity feeds its own
antecedent form a cycle. Under naive SLD such a corpus can diverge in
one clause order and succeed in another. An engine with tabling or
bottom-up evaluation is immune. This repository's own gates are
fail-closed against divergence: the check proves every obligation under
the bounded search above. Those bounds cut a divergent branch, and the
check reports it as a failed obligation instead of hanging. Left
recursion — a head that unifies with its own leftmost body goal — is
the shape that makes an open query's termination depend on load order.
The gate checks it rather than asserts its absence. Every
`tools/goal.py check` runs `recursion-check` over the loaded
composition and rejects one, printing the rule-clause count that it
scanned. The shipped corpus holds none.

Authoring notes (v1):

- State guideline knowledge and nothing else in an ACE document: no
  witness seed facts, no proper-name stand-ins, no authored probe
  queries. The compiler derives its own obligations.
- Put reusable domain vocabulary, not per-statement fixtures, in
  `lexicon.ulex`.
- Keep every ulex lexeme reachable. An entry whose lexeme no document
  uses rejects. So does an entry repeated in the file, or one that the
  vendored Clex already provides byte-for-byte.
- Write one statement per sentence: split "…, and if A then B" into
  separate sentences.
- Keep quantified restrictors out of modal complements. A universally
  quantified rule nested inside a modal box rejects
  (`operator_scoped_rule`). State the quantification in the antecedent
  and let the modal box wrap only the consequent.
- A prepositional phrase attaches to the verb.
- Modifying a noun with `of` rejects
  (`condition_shape(relation(A,of,B))`). Rewrite
  `every clinician of a clinic` either as a relative clause,
  `every clinician who works at a clinic`, or as one compound noun with
  its own lexicon entry, `every clinic-clinician`.
- Count nouns take an explicit determiner.
- `for` as a preposition needs a `prep(for,for)` user-lexicon entry.
- An indefinite consequent entity that repeats the noun of the
  antecedent's first condition (`If a patient … then a patient …`)
  mints a fresh referent. That referent's clause head unifies with its
  own leftmost body goal: the document compiles, and `check` then
  rejects the composition as `proof, left_recursive(…)`. Refer back to
  the antecedent referent (`the patient`), or give the consequent
  entity its own noun.

### Question projection

The compiler's `question` mode compiles one ACE question against the
same v1 vocabulary:

```sh
swipl -q -f none -F none -s vendor/ape/prolog/ace_to_pl.pl -g main \
  -t 'halt(9)' -- question <ape-tree-dir> <qid> [<ulex>]   # ACE on stdin
```

The input must be exactly one sentence line that parses to one root
question box. `<qid>` follows the docid grammar. Success emits four
lines. Line 1 is a generated-file comment. Line 2 is the ground
`'$guideline_query'(v1, Qid, ace_sha256(H), ulex(none | sha256(H)))`
record. Line 3 is a `% Q1:` comment with the verbatim sentence. Line 4
is one `'$guideline_query_projection'(goal(Conj), answers(Manifest))`
term. `Conj` is an explicit `','/2` conjunction of v1 goals rendered
through the rule-antecedent pipeline. The root context is `actual`,
and referents stay variables. A modal box contributes its
`guideline_operator/3` edge before its payload goals, under a shared
existential context variable. `Manifest` lists one `answer(Var, Desc)`
row per wh-placeholder in source order. `Desc` is `noun(Noun, Class)`
when exactly one same-box `object/6` types the placeholder; otherwise
it is `wh(who)` or `wh(what)`. Goal and manifest share variables
inside the one projection term.

Supported forms: `wh(who | which | what)` and yes-no questions over
conjunctive v1 content, with modal boxes at any nesting of themselves.
Structural and blocker failures reject with class `unsupported` and
exit 1. `query_expected(S)` means that no root question exists.
`query_sentences(N)` means that the input is not exactly one sentence.
`query_unsupported(Blocker, S)` names a blocking construct. Blockers
are `universal`, `disjunction`, `classical_negation`, `naf`, and the
unsupported tags `wh(howm | how | where | when)`. A foreign leaf
rejects as `leaf(Name/Arity)`; a malformed placeholder rejects as
`marker(_)`. Inherited
parser, input, and load failures keep their own classes, details, and
exit codes. The projection emits no document
indicators, no declarations, and no proof obligations. It never
enters a document, aggregate-check, or recursion-check composition.
`goal.py check` re-derives every committed query separately and
compares the bytes.

### Query answers

The compiler's `answer` mode solves one compiled query against a
loaded composition:

```sh
swipl -q -f none -F none -s vendor/ape/prolog/ace_to_pl.pl -g main \
  -t 'halt(9)' -- answer <manifest> <query-pl>
```

`<manifest>` uses the aggregate manifest grammar. The payload column
must name readable files, and the mode never parses payload terms. A
0-byte manifest is the empty composition: the mode still declares the
v1 indicators and solves against no clauses. `<query-pl>` must read
as exactly two terms in order: the ground `'$guideline_query'/4`
record, then the `'$guideline_query_projection'/2` term. The mode
reads the query file as data and never consults it. Comments and
layout carry no meaning here; the `check` gate pins committed bytes
separately.

Success emits a two-line artifact on stdout: a generated-file
comment, then one ground term
`'$guideline_answers'(v1, Qid, query_sha256(H), result(R))`. `H` is
the SHA-256 of the raw query-file bytes. The solver runs under fixed
bounds: depth 100 for each derivation, one 100000-inference budget
that is cumulative across backtracking for the whole query, and
1000000 inferences for the whole run. For a wh query (`answers` rows
present), `R` is `solutions(Sols)`, or `indeterminate(limit)` when a
bound trips. Each distinct solution contributes one `sol(Values)`
row; rows follow the standard order of terms, and values follow the
answer-manifest order. For a yes-no query
(`answers([])`), the first proof is conclusive. `R` is `yes`,
`no(finite_failure)` on exhaustive failure, or `indeterminate(limit)`
when a bound trips before any proof. A nonground solution rejects
with class `proof` as `nonground_solution(Qid)`. A malformed query
file rejects with class `check_load` as `query_file(<why>)`. Manifest
and composition load failures keep the aggregate classes and details.

Committed query artifacts live under `guidelines/<id>/queries/`:
`<qid>.ace` sources at the root, compiled queries under `pl/`, answer
artifacts under `answers/`, and proof traces under `traces/`.
`python3 -P tools/goal.py queries <id>` derives every artifact in
memory and writes only after every derivation succeeds. `check`
re-derives each file per query twice and compares the bytes. A
committed answer must be `yes` or nonempty `solutions(...)`;
committed queries stay demonstrations. The `queries` and `check`
commands bound every compile, answer, and trace subprocess at 30
seconds of wall-clock time. A run that exceeds the bound fails the
gate. The direct `swipl` invocation above has no process bound.

### Proof traces

The compiler's `trace` mode re-proves the positive claims of one
answer artifact against a loaded composition:

```sh
swipl -q -f none -F none -s vendor/ape/prolog/ace_to_pl.pl -g main \
  -t 'halt(9)' -- trace <manifest> <query-pl> <answers-pl>
```

The manifest and query file follow the answer-mode rules.
`<answers-pl>` must read as the answer artifact for the same query:
one ground `'$guideline_answers'` term. The version, qid, and query
hash must match. The result must fit the query's mode. A malformed
or mismatched answers file rejects with class `check_load` as
`answers_file(<why>)`.

Success emits a two-line artifact on stdout: a generated-file
comment, then one ground term `'$guideline_traces'(v1, Qid,
query_sha256(H), answers_sha256(A), result(R))`. `A` is the SHA-256
of the raw answers-file bytes. `R` mirrors the answer result with a
proof in place of each positive claim. `yes` becomes `yes(P)`. Each
`sol(Values)` row becomes `sol(Values, P)` in file order.
`no(finite_failure)` and `indeterminate(limit)` carry no positive
claim and stay verbatim.

`P` is `proved(Nodes)`, `unproved(finite_failure)`, or
`unproved(limit)`. Each proof node is `clause(sentence(DocId, S),
clause_sha256(Hex), Children)`. It names the clause that resolved
the goal by document and sentence number. `Hex` is the SHA-256 of
that clause's rendered document line with its newline. A re-checked
negation-as-failure goal freezes as a `naf(Goal)` leaf among a
clause node's children. Root nodes are always clause nodes. The
prover is a directed first-proof interpreter over the loaded
clauses. Each row's search runs under depth 1000 and 100000
inferences. The whole run is bounded at 1000000 inferences. The
interpreter's depth measure is its own; it is not comparable with
the answer mode's engine measure. A negation site re-checks under
the same bounds. A bound that trips inside a negation makes the
whole row `unproved(limit)`, never a false failure. When the
whole-run bound trips, the result becomes `indeterminate(limit)` in
place of the mirror. The direct `swipl` invocation has no process
bound.

`check` re-derives each committed trace twice, compares the bytes,
and resolves every `clause_sha256` to exactly one clause line of the
committed document under `pl/`. A committed trace must prove its
answer: `yes(proved(...))`, or solution rows that are all proved.
`check` prints one `goal: traces <id> <n> traces; nodes=<k>` meter
per guideline beside the queries meter.

