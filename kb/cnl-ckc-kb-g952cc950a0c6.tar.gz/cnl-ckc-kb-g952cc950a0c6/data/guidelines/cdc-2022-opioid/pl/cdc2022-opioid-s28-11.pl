% cdc2022-opioid-s28-11.pl compiled from ACE by ace_to_pl; regenerate via tools/goal.py; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/3).
:- discontiguous(guideline_document/3).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-s28-11',ace_sha256(c6ef0854ffc7b4fb8bd7b120120fb37773cda24c33fbd5b373ef0852e8bd7e73),ulex(sha256('4a882a1996ea910df0fbf91fea897c0805e67d48f9e1ce2fcdbbbd9250c193ae'))).
% S1: Every clinician may elicit a meaningful-functional-goal from a patient.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s28-11',1,box(1),[A]),may) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s28-11',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',1,ref(2),[A]),'meaningful-functional-goal',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s28-11',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',1,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s28-11',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',1,ref(3),[A]),patient,countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s28-11',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',1,ref(3),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s28-11',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',1,ref(4),[A]),elicit) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s28-11',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',1,ref(4),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s28-11',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',1,ref(4),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s28-11',1,ref(2),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s28-11',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',1,ref(4),[A]),from,'$guideline_id'(product,'cdc2022-opioid-s28-11',1,ref(3),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
% S2: Every clinician may use a meaningful-functional-goal during an opioid-benefit-assessment.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s28-11',2,box(1),[A]),may) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s28-11',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',2,ref(2),[A]),'meaningful-functional-goal',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s28-11',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',2,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s28-11',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',2,ref(3),[A]),'opioid-benefit-assessment',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s28-11',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',2,ref(3),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s28-11',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',2,ref(4),[A]),use) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s28-11',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',2,ref(4),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s28-11',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',2,ref(4),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s28-11',2,ref(2),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s28-11',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',2,ref(4),[A]),during,'$guideline_id'(product,'cdc2022-opioid-s28-11',2,ref(3),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
% S3: Every clinician may use a meaningful-functional-goal during a continued-opioid-benefit-risk-weighing.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s28-11',3,box(1),[A]),may) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s28-11',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',3,ref(2),[A]),'meaningful-functional-goal',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s28-11',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',3,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s28-11',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',3,ref(3),[A]),'continued-opioid-benefit-risk-weighing',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s28-11',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',3,ref(3),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s28-11',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',3,ref(4),[A]),use) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s28-11',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',3,ref(4),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s28-11',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',3,ref(4),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s28-11',3,ref(2),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s28-11',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s28-11',3,ref(4),[A]),during,'$guideline_id'(product,'cdc2022-opioid-s28-11',3,ref(3),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
