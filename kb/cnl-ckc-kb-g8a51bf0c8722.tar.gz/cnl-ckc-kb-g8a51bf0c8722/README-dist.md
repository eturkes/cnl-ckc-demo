# cnl-ckc knowledge base export

This archive is a BagIt 1.0 bag. It holds the compiled clinical-guideline knowledge base from the cnl-ckc repository. The archive name and the name of its root directory give the source commit.

## Verification

Run `sha256sum -c manifest-sha256.txt tagmanifest-sha256.txt` from this directory. Each line must report OK.

## Contents

- cdc-2022-opioid (redistributable): 385 documents.

## Review status

Each shipped document has a label row in release-manifest.tsv.

- approved: 0 documents.
- rejected: 0 documents.
- contested: 0 documents.
- stale: 0 documents.
- unreviewed: 385 documents.

## Rights

- cdc-2022-opioid (redistributable): "All material in the MMWR Series is in the public domain and may be used and reprinted without special permission; citation as to source, however, is appreciated." Source: https://www.cdc.gov/mmwr/about.html, retrieved 2026-07-22. CDC statement quoted in the guideline README, Rights and attribution section. CDC does not endorse this project.

## Replay

These commands run in the source repository at the commit that this archive names.

- compile: ckc compile <guideline-id>
- check: ckc check
- load: swipl -q -s data/guidelines/schema.pl -s data/guidelines/<guideline-id>/pl/<docid>.pl

## Compiled Prolog schema

Status: one schema with the identifier `1`. Every document and every
question compiles under it. Until the first publication the schema
evolves in place: each revision recompiles the whole corpus and every
fixture, and the identifier stays `1`. The predicate set below is the
public interface. An optional per-guideline table, `vocabulary.tsv`,
adds the time annotations of the section "Vocabulary table and time
annotations" and the grade and preference annotations of the section
"Strength annotations" below. The compiler takes the table from an explicit
invocation argument and never infers it from content. Authored
questions reject in document compiles; the separate question mode below
compiles one question into a query projection over the same vocabulary.

Sentences project onto a closed reserved vocabulary. Source words —
nouns, verbs, adjectives, prepositions — stay opaque data atoms and
never become predicate functors. The schema is therefore language- and
domain-neutral:

| Predicate | Meaning |
| --- | --- |
| `guideline_schema_version(Version)` | schema identifier of this document (`1`) |
| `guideline_document(DocId, ace_sha256(H), ulex(none \| sha256(U)), vocabulary(none \| sha256(T)))` | document record + source digests |
| `guideline_entity(Context, Ref, Noun, Class)` | an entity referent and its noun/class |
| `guideline_cardinality(Context, Ref, Unit, Comparison, Count)` | that referent's quantity payload, verbatim |
| `guideline_event(Context, EventRef, Lemma)` | an event referent and its verb |
| `guideline_arg(Context, EventRef, Position, Ref)` | participant at `Position` (1-based, DRS order) |
| `guideline_pp(Context, EventRef, Preposition, Ref)` | prepositional attachment on the event |
| `guideline_property(Context, PropertyRef, Lemma, Polarity)` | adjectival property (`pos`) |
| `guideline_operator(OuterContext, InnerContext, Operator)` | reified modal/negation wrapper: `InnerContext`'s content stands under `Operator` relative to `OuterContext` |

The six time annotations (`guideline_interval/6`,
`guideline_recurrence/4`, `guideline_frequency/5`, `guideline_order/4`,
`guideline_recurrence_window/7`, `guideline_range/3`), the three
strength annotations (`guideline_grade/5`, `guideline_preference/4`,
`guideline_qualifier/4`) and the unit annotation `guideline_unit/3`
complete the vocabulary. The comparison built-ins
`guideline_satisfies/4` and `guideline_satisfies/6` test the conditions
of rules and questions; the section "Comparison conditions" below defines
them. The sections "Vocabulary table and time
annotations" and "Strength annotations" below define them. In the record, `H` is the SHA-256 of the raw ACE bytes,
`U` the SHA-256 of the guideline's user lexicon, and `T` the SHA-256
of its raw `vocabulary.tsv` bytes. `none` means that the file does not
exist.

`Comparison` is exactly one of `eq`, `geq`, `greater`, `leq`, `less`,
`exactly`, `na`, or `about` (an approximate time quantity, below). A
plain number (`eq`) states at least that many, as in ACE: `3 cars` allows
more cars. `exactly` states the count itself. The compiler copies units
and counts through as data and performs no arithmetic and no modal
inference: a cardinality clause of a fact or a rule head records what the
sentence said, nothing more. A condition with a comparison compares; the
section "Comparison conditions" below states how.

Every one of those values is reachable, but not from every position. An
upper-bounding determiner (`at most n`, `exactly n`, `less than n`) is
scoped. At the root of an asserted sentence, ACE groups the conditions
that the determiner binds into a condition list. The schema has no construct
for that scope, so the document rejects with
`unsupported, root_condition([…])` rather than flatten an upper bound
into an existential claim; `tests/red/unsupported--v1-root-at-most.ace`
pins the detail. The same phrase inside a rule or an operator box
carries no group and compiles, emitting `leq`, `exactly`, or `less`
under that context. `at least n` and `more than n` bound below, are
never grouped, and compile in any position.

`Context` is `actual` for asserted content, or a generated operator
context:

```
Context      ::= actual | '$guideline_id'(context, DocId, S, box(B), Deps)
Operator     ::= should | must | can | may | '-'
OperatorEdge ::= guideline_operator(OuterContext, InnerContext, Operator)
```

The compiler reifies modality and classical negation as data, never as
inference. Each DRS operator box becomes one `guideline_operator/3`
edge from its enclosing context to a fresh box context. The compiler
emits that edge before the box's payload clauses, which carry the box
context in their own `Context` argument. The operator atoms are the DRS
functors themselves (`-` is classical negation), so a non-English
frontend produces the same tags. ¬SHOULD(P) and SHOULD(¬P) stay
structurally distinct, and the compiler performs no deontic, modal, or
classical inference. `box(B)` numbers a sentence's operator boxes in
whole-sentence preorder. `Deps` follows the Skolem dependency rule:
empty for root facts, the antecedent's top-level referents for
consequent boxes. A consequent operator context is therefore a
per-antecedent-solution witness. In rule bodies, an operator box binds
an existential context variable — `guideline_operator(Outer, V, Op)`
plus payload goals that share `V`. Matching is Horn-monotone structure
satisfaction over whatever documents are loaded. Extra clauses under a
producer context therefore never block a match, and two body boxes may
bind one producer context whose payload satisfies both. A consumer that
wants unwrapped content only keeps `Context = actual`. An
operator-aware consumer adds one recursive walk over
`guideline_operator/3` edges (a `ctx_desc/2` descendant relation) to
collect content under a modality.

Negation-as-failure ("does not provably …") in a rule antecedent
compiles to an executable `\+ (…)` over the box's goals. Its scope is
the loaded aggregate: the engine evaluates `\+` against whatever
document set is co-loaded, so absence is corpus-relative, never
document-local. Negation-as-failure in a consequent or a root fact
rejects; assertion-by-absence is meaningless.

A universally quantified sentence becomes one Horn clause per
consequent condition. All clauses of a rule variant share one logical body; each clause line renders it with its own canonical variable letters, so two lines of one variant are equal up to variable renaming. A nested `if … then if … then …` consequent curries into
one rule whose antecedent concatenates the nested domains. An
antecedent that contains one disjunction splits into two variants whose
bodies are the shared conditions plus that arm. The bundle keeps one
sentence comment, with variant-1 clauses and then variant-2 clauses,
contiguous. The compiler Skolemizes a referent introduced only in the
consequent to
`'$guideline_id'(product, DocId, SentenceId, ref(N), Deps)`. `Deps` is
the concatenation of every curried antecedent segment's top-level
referents in DRS order; a split variant appends its arm's top-level
referents. A referent introduced inside an operator or
negation-as-failure (NAF) box contributes nothing to any `Deps` list:
it is consequent-inaccessible and stays a box-local existential. `N` is
the referent's first-occurrence position in the sentence's unsplit
expansion. Both variants of a split mint the same `ref(N)`,
distinguished by `Deps`. The constructor's first argument names the
term's role: `context` for an operator box, `product` for a consequent
referent, `witness` for a proof instance (below). All three name the
compiler's own chosen stand-in — never a source-given name, real-world
identity, or uniqueness claim. Because facts and derived heads share
one vocabulary, a rule body consumes another document's facts or heads
by ordinary resolution.

Every document opens with the same declaration block: `multifile`
and `discontiguous` for all 19 indicators, whether or not it
populates them. After the block come `guideline_schema_version(1).`,
the document record, and then, per sentence, a
`% S<n>: <verbatim sentence>` comment with that sentence's contiguous
clauses in deterministic order. Any set of documents therefore
co-loads into one engine in any order with no warnings. Names that
begin with `guideline_` and the identity constructor `'$guideline_id'`
are reserved: a colliding name rejects the document rather than
silently shadow schema vocabulary. The compiler scans both the parsed
sentence and every lexicon entry — used or not — for one.
`guideline_part/3` is reserved for a later unit and stays unemitted. Shapes still outside the schema (group coordination, disjunctive
consequents, rules scoped inside an operator) reject with a canonical
`ace_to_pl_error(unsupported, …)` line. A question inside a document
rejects with `question_not_supported(Form, S)`, where `Form` is
`wh(Tag)`, `universal`, or `yesno`.

Compilation is checked, not asserted. Every compile derives the
document's proof obligations and discharges them before it emits
anything. Appending `proof` to the invocation prints the derivation
payload in place of the document. The payload is one
`'$guideline_proof'(DocId, S, variant(K), witness(Facts), prove(Heads))`
term per fact group and per rule variant. `Facts` is that group's own
positive body under a witness substitution; NAF boxes contribute
nothing, by design. `Heads` is that group's clause heads under the same
substitution. The compiler asserts each witness ahead of the document's
rule clauses, proves every head under bounded search, then retracts.
The bounds are depth 4000 inside 1,000,000 inferences; a search that
exceeds either bound counts as underivable. A group whose heads stay
non-ground under its own witness rejects with
`proof, nonground_obligation(…)`. A group whose heads do not derive
rejects with `proof, underivable_obligation(…)`. Both exit 1. Witness terms carry the document's own document, sentence, and variant coordinates, so a witness never collides with another document's constructed terms. Success
is modus ponens over that sentence's own projection.

`ckc v1 aggregate-check <manifest>` replays those obligations across a
composition in the verified Rust engine. The manifest is strict: one `<compiled-pl>` TAB
`<payload>` row per document, with the final newline required. A 0-byte
file means the empty composition. The engine loads every document
into one composition; any load diagnostic is a failure. It checks that the
distinct document records equal the manifest row count. It then
re-derives every obligation against the whole batch. Co-loading therefore cannot break a document's derivations, and the engine evaluates negation-as-failure against the composition it will actually run in. The replay does not isolate documents: a rule in one document can derive another document's obligation head, so the per-document replay above is the check that each document's own clauses suffice. The check reports
`ace_to_pl aggregate ok <N> documents <G> obligations`.

`ckc v1 recursion-check <manifest>` loads that same composition and
ignores the payload column. It proves that no clause head unifies with its own
leftmost body goal, renaming the goal apart first the way SLD renames a
clause. A match rejects as `proof, left_recursive(Site, Name, Arity)`,
where `Site` is the offending clause's own `sentence(DocId, S)` when it
carries one. The scan is structural, so its verdict is load-order
independent. It reports
`ace_to_pl recursion ok <N> documents <M> rule clauses`; the count
names what it read.

Payloads are evidence, not authority: the gate checks `<G>` against the
composition rather than take it from the payload stream. Before the
replay proves any head, four conditions must hold:

- The obligation set must cover exactly the sentence identities that
  the loaded documents themselves carry (`missing_obligation` /
  `extra_obligation`).
- Its `(document, sentence, variant)` keys must be unique
  (`duplicate_obligation`), with variants numbered `1..K` per sentence
  (`variant_sequence`).
- No group may prove an empty head list (`empty_obligation`).
- A nonempty payload file must end in the newline that its last term
  wrote (`check_load, payload_term(…)`).

An emptied, truncated, repeated, or misattributed payload therefore
fails the replay instead of shrinking it. Manifest rows bind product to
payload for provenance; replay soundness rests on that composition-wide
coverage. One residue is open by construction: dropping the LAST
variant of a multi-variant sentence leaves coverage complete and
variant numbering contiguous. The schema carries no per-sentence
variant count to check it against.

Compiled documents are a normal logic program (Horn clauses plus negation as failure), so termination is the
consuming engine's responsibility, not a property that the schema can
promise. Facts and derived heads share one vocabulary by design; that
is what lets one document's rules consume another's clauses. The same
sharing lets an authored rule whose consequent entity feeds its own
antecedent form a cycle. Under naive SLD such a corpus can diverge in
one clause order and succeed in another. Tabling or bottom-up evaluation removes that clause-order dependence when the recursion reaches finitely many terms; a recursion that builds ever deeper Skolem terms can still run without end. This repository's own gates are
fail-closed against divergence: the check proves every obligation under
the bounded search above. Those bounds cut a divergent branch, and the
check reports it as a failed obligation instead of hanging. Left
recursion — a head that unifies with its own leftmost body goal — is
the shape that makes an open query's termination depend on load order.
The gate checks it rather than asserts its absence. Every
`ckc check` runs `recursion-check` over the loaded composition and
rejects one, printing the rule-clause count that it scanned. The shipped corpus holds none.

Authoring notes:

- State guideline knowledge and nothing else in an ACE document: no
  witness seed facts, no proper-name stand-ins, no authored probe
  queries. The compiler derives its own obligations.
- Put reusable domain vocabulary, not per-statement fixtures, in
  `lexicon.ulex`.
- Keep every ulex lexeme reachable. An entry whose lexeme no document
  uses rejects. So does an entry repeated in the file, or one that the
  vendored Clex already provides byte-for-byte.
- Write one statement per sentence: split "…, and if A then B" into
  separate sentences.
- Keep quantified restrictors out of modal complements. A universally
  quantified rule nested inside a modal box rejects
  (`operator_scoped_rule`). State the quantification in the antecedent
  and let the modal box wrap only the consequent.
- A prepositional phrase attaches to the verb.
- Modifying a noun with `of` rejects
  (`condition_shape(relation(A,of,B))`). Rewrite
  `every clinician of a clinic` either as a relative clause,
  `every clinician who works at a clinic`, or as one compound noun with
  its own lexicon entry, `every clinic-clinician`.
- Count nouns take an explicit determiner.
- `for` as a preposition needs a `prep(for,for)` user-lexicon entry.
- An indefinite consequent entity that repeats the noun of the
  antecedent's first condition (`If a patient … then a patient …`)
  mints a fresh referent. That referent's clause head unifies with its
  own leftmost body goal: the document compiles, and `check` then
  rejects the composition as `proof, left_recursive(…)`. Refer back to
  the antecedent referent (`the patient`), or give the consequent
  entity its own noun.

### Vocabulary table and time annotations

The time annotations type the time limits that a sentence states. A
guideline opts in with the table `guidelines/<id>/vocabulary.tsv`. The
table maps source words onto closed identifiers, so no annotation names
a source word:

```
# format: kind<TAB>lemma<TAB>value
unit	day	day
relation	before	before
spacing	at	interval
window	during	window
frequency	per	period
approximation	approximate	about
range	to	minimum
strength	category-A-recommendation	strong
evidence	evidence-type-1-recommendation	high
preference	preferred	preferred
alternative	instead-of	alternative
qualifier	ideally	ideality
qualifier	feasible	applicability
```

The header line is fixed bytes. The table holds at least one row, and
every row has three fields and ends with a newline. A row whose first
byte is `#` is a comment and rejects. A `unit` row maps a noun lemma
onto a calendar unit (`second`, `minute`, `hour`, `day`, `week`,
`month`, `year`). A `relation` row maps a preposition onto a role
(`duration`, `within`, `after`, `before`). A `spacing` row pairs a
preposition with a frame noun for recurrence, as in
`at an interval of 3 months`. A `window` row pairs a preposition with
the frame noun of a time window, as in
`during a window of 1 week of the methadone-start`. A `frequency` row
names the preposition of a count per period, as in `per 1 day`; its
value is always `period`. An `approximation` row names an adjective
that marks a time quantity as approximate, as in `2 approximate hours`;
its value is always `about`. A `range` row names the preposition that
joins the upper end of a minimum stated as a range, as in
`for at least 8 hours to 12 hours`; its value is always `minimum`.
A `strength` row maps a grade noun onto the strength of a
recommendation (`strong`, `conditional`). An `evidence` row maps a
grade noun onto the certainty of its evidence (`high`, `moderate`,
`low`, `very_low`). A `preference` row names an adjective that marks
the preferred option on a copula, as in `An NSAID is preferred.`; its
value is always `preferred`. An `alternative` row names the preposition
that joins the option a preference replaces, as in
`… prescribe an immediate-release-opioid instead-of an ER-LA-opioid`;
its value is always `alternative`. A `qualifier` row maps an adverb,
or the adjective of a copula, onto the function class of a qualifier:
`usuality`, `ideality`, `focus`, `manner`, `force`, `possibility` or
`applicability`. The section "Strength annotations" below uses these
rows.

A lemma is one or more bytes above 0x20, none of them 0x7F, that form
valid UTF-8. A noun occurs in at most one `unit`, `strength` or
`evidence` row, and a noun in such a row is never also a frame noun. A
pair of a preposition and a frame noun occurs once across the `spacing`
and `window` rows. A preposition occurs in at most one `relation`,
`frequency` or `range` row. A preposition in an `alternative` row
occurs in no `relation`, `spacing`, `window`, `frequency` or `range`
row. A lemma occurs in at most one `approximation`,
`preference` or `qualifier` row. The later row of a conflict reports
it. The checks run in row order: comment, field count, lemma, kind,
value, duplicates. `ckc check` rejects any
other table with `ckc: vocabulary: <path>: <why>`, where `<why>` names the
broken law and, for a row law, ends with `at row <n>`. The compiler, and
so `ckc compile`, rejects it with class `vocabulary_load` (below). A
guideline folder that holds a file named `temporal.tsv` is refused by every command that
reads the table: rename the file to `vocabulary.tsv` and replace its
header with the one line above.

The compiler takes the table from an explicit argument. `-` in a file
slot means no file:

```sh
swipl -q -f none -F none -s <ape-tree-dir>/prolog/ace_to_pl.pl -g main \
  -t 'halt(9)' -- <ape-tree-dir> <docid> <vocabulary.tsv | -> <ulex | -> [proof]
```

A table that does not load fails the compile with class
`vocabulary_load` and exit 2; the compiler never falls back to no
table. The word `proof` in the vocabulary or ulex slot rejects with
class `usage` as `vocabulary_arg(proof)` or `ulex_arg(proof)`. A
leading `v1`, `v2` or `v3` token and every other argument vector reject
with class `usage` as `argv(Argv)`. A document compiled with a table
records the table digest in `vocabulary(sha256(T))`; without one it
records `vocabulary(none)`. The declaration block, the identifier line
and every clause shape are the same either way.

| Predicate | Meaning |
| --- | --- |
| `guideline_interval(Context, Event, Role, Quantity, Unit, Anchor)` | `Event` stands in the time relation `Role` to `Anchor`, bounded by `Quantity` in `Unit`; `Anchor` is `none` when the sentence names no reference point |
| `guideline_recurrence(Context, Event, Quantity, Unit)` | successive occurrences of `Event` lie `Quantity` in `Unit` apart |
| `guideline_frequency(Context, Event, Counted, Period, Unit)` | `Event` involves the stated count of `Counted`'s items in each period of `Period` in `Unit` |
| `guideline_order(Context, Event, Relation, Anchor)` | each occurrence of `Event` lies `before` or `after` `Anchor`; no time bound is stated |
| `guideline_recurrence_window(Context, Event, Gap, GapUnit, Anchor, Length, LengthUnit)` | consecutive occurrences of `Event` inside the window that starts at `Anchor` and lasts `Length` in `LengthUnit` lie `Gap` in `GapUnit` apart |
| `guideline_range(Context, Low, High)` | the minimum that the interval quantity `Low` states lies from the count of `Low` to the count of `High`; `High` bounds nothing about the event |

An annotation never replaces a clause. It follows the `guideline_pp`
clause that it types, in the same context and with the same rule body.
A document compiled without a table never carries an annotation.

The compiler reads these patterns from the parsed sentence. A time
quantity is a referent whose noun is a `unit` lemma. Its cardinality
clause carries the comparison and the count. The patterns read
referents by their noun anywhere in the document. A referent whose noun
is no unit and no frame noun is a plain referent.

- Interval: the event carries a `relation` preposition whose object is
  a time quantity. The anchor is the single `of` object of that
  quantity in the same context, as in
  `within at most 4 weeks of the therapy-start`.
- Recurrence: the event carries a `spacing` preposition with its frame
  noun, and the frame has a single `of` object that is a time quantity,
  as in `at an interval of at most 3 months`.
- Order: the event carries a `relation` preposition with role `before`
  or `after`, and its object is a plain referent. The object may come
  from the antecedent or from an earlier sentence.
- Count per period: the event carries a `frequency` preposition whose
  object is a time quantity with an exact count and no `of` object. The
  counted item is the second participant of the event. It is a count
  noun with a comparison and a count of at least 1, as in
  `receives 2 buprenorphine-administrations per 1 day`.
- Scoped recurrence: the event carries a `window` preposition. Its
  frame is one count noun with one `of` object, a time quantity, and
  that quantity has one `of` object, a plain referent. The event must
  also carry a recurrence. Each recurrence on that event becomes a
  `guideline_recurrence_window` clause, and no plain
  `guideline_recurrence` clause is emitted for it.
- Approximate time limit: an `approximation` adjective on a typed time
  quantity, or on the spacing or window frame of the quantity, marks it
  approximate. Its `guideline_cardinality` clause then has the
  comparison `about` in place of `eq`, as in
  `at an approximate interval of 2 hours`. The comparison `about` names
  no tolerance; `about 2` matches only `about 2`. An approximate
  quantity must state an exact count.
- Ranged minimum: a `range` preposition whose object is an exact time
  quantity pairs with the one `at least` interval on the same event,
  as in `for at least 8 hours to 12 hours`. The pair emits
  `guideline_range(Context, Low, High)` beside the interval clause. The
  pair needs the same unit and a smaller lower count. The interval keeps
  its own `at least` comparison.

An interval or recurrence quantity must be a count noun with a
comparison and a count of at least 1. Every other shape of these
patterns rejects with class `unsupported` as `temporal_shape(Why, S)`:

| `Why` | Shape |
| --- | --- |
| `no_bound` | the quantity has no comparison, or it is not a count noun |
| `zero_bound` | the count is below 1 |
| `duration_anchor` | a `duration` role names an anchor |
| `anchor_count` | an interval quantity has two or more `of` objects, a frame does not have exactly one, or a recurrence quantity has one |
| `shared_quantity` | two patterns claim one quantity or one frame |
| `frame_shape` | the frame is not exactly one count noun, or its `of` object is not a time quantity |
| `anchor_shape` | the anchor is itself a time quantity or a frame |
| `frequency_shape` | a count per period breaks its pattern |
| `window_shape` | a time window breaks its pattern |
| `approximate_bound` | an approximate quantity states no exact count |
| `range_shape` | a ranged minimum breaks its pattern |

An `of` link that no pattern consumes rejects. The compiler checks the
patterns left to right, then the shared claims, then each
negation-as-failure scope. The first violation rejects.

Annotations are data, never schedules. `duration` means that `Event`
lasts that long. `after` means that `Event` occurs that long after
`Anchor`, and `before` that long before it. `within` means that `Event`
and `Anchor` lie that far apart, in either order. `geq` and `leq`
include the bound; `greater` and `less` exclude it. A unit is a calendar
label: the compiler calculates no date, and only a condition compares
quantities in different units (section "Comparison conditions"). Two
annotations on one event state both limits, so a range is a pair on one
anchor. A condition compares by value: a fact for `geq 30` meets a
condition for `geq 20`. A count per period does not set
calendar buckets, a first occurrence or a minimum gap. A window does not
set the first occurrence and says nothing about occurrences outside it.

An abbreviation such as `d` or `h` can type as a unit. The corpus
lexicon must declare it as a count noun, and a `unit` row must map it.
ACE also parses `3 d` as a measured number, but the compiler
rejects that form as `unresolved_argument`.

Documents compiled with and without a table load into one composition,
and a question runs against any composition. Certification takes the
raw table bytes, so `ckc certify` checks the record digest and every
annotation against the table.

### Strength annotations

The strength annotations type the grade of a recommendation, the
preference of one option over another and the qualifiers of a
statement, such as `ideally`, `typically` or `when feasible`. They need
the `strength`, `evidence`, `preference`, `alternative` and `qualifier`
rows of the vocabulary table. Only documents carry them; question mode
never adds them.

| Predicate | Meaning |
| --- | --- |
| `guideline_grade(Context, Rec, Dimension, Value, Label)` | the recommendation `Rec` has, in `Dimension` (`strength` or `evidence`), the common value `Value`; `Label` is the referent whose noun is the source's own grade label |
| `guideline_preference(Context, Event, Preferred, Alternative)` | in `Event`, the source prefers the option `Preferred` to `Alternative`; `Alternative` is `none` when the source names no other option |
| `guideline_qualifier(Context, Event, Class, Word)` | the source qualifies `Event` with the word `Word`, whose function class is `Class` |

The compiler reads these patterns from the parsed sentence:

- Grade: a fact sentence states `R is a L` in the context `actual`, and
  the noun of `L` is in a `strength` or `evidence` row, as in
  `A recommendation is a category-A-recommendation and is an evidence-type-4-recommendation.`
  The grade clause follows the `be` event's second participant. A
  document has at most one grade for each dimension. The grade applies
  to every statement of its document: `Rec` carries the document
  identifier. A grade noun in a rule, an operator box, a
  negation-as-failure group or a question adds no grade.
- Preference: an event carries one `alternative` preposition, or a
  copula `X is A` has an `A` from a `preference` row. A preference
  copula prefers `X`; any other event prefers its second participant.
  The alternative is the object of the `alternative` preposition, or
  `none`. The preference clause follows the preposition's `guideline_pp`
  clause, or the copula's second participant when no alternative
  exists. It takes the context of its event, so a preference in a rule
  antecedent becomes a body goal of every clause of the rule, and a
  preference under an operator stands in that operator's context.
- Qualifier: an adverb on an event has a `qualifier` row, as in
  `Every clinician should ideally review a record.` The qualifier clause
  takes the place of the adverb in the order of the sentence. A copula
  `X is A` whose adjective `A` has a `qualifier` row also gets a
  qualifier clause, after the copula's second participant, as in
  `If a treatment is feasible then …`. Each such adjective of the copula
  gets its own clause, and the adjective clauses stay. An adjective on a
  noun, as in `X is a feasible option`, qualifies a thing and adds no
  qualifier. A qualifier takes the context of its event, as a
  preference does. An adverb without a `qualifier` row rejects as
  `condition_shape`.

The class of a qualifier names the function of the word:

| Class | Words, for example | Function |
| --- | --- | --- |
| `usuality` | typically, usually, often, regularly | how usual or how frequent the event is |
| `ideality` | ideally, optimally, preferably | the ideal or best form of the event |
| `focus` | particularly, especially, importantly | the source emphasizes the event in its scope |
| `manner` | carefully, closely, cautiously | how the event is carried out |
| `force` | strongly | the strength of the wording of the advice |
| `possibility` | possibly, potentially, likely | the event is possible or likely |
| `applicability` | appropriate, feasible, possible, needed, indicated | the event or thing fits the case |

The context of a clause, not the class of its qualifier, tells whether
the clause is asserted. An adverb of class `usuality`, `ideality`,
`possibility` or `applicability` weakens what its clause says. Thus such
an adverb cannot qualify an asserted clause: a fact or a rule head that
stands under no modal operator (`should`, `must`, `can`, `may`). A
classical negation alone does not make a clause unasserted. Write the
claim under a modal operator, as in
`… then the patient can possibly need a bowel-therapy.` An adverb of
class `focus`, `manner` or `force` and every copula adjective can
qualify an asserted clause. A qualifier in a condition is a goal that a
matching fact must meet.

A qualifier belongs to the description of its event. A negation or an
operator covers the event together with its qualifiers:
`it is recommended that the clinician does not abruptly discontinue an
opioid` recommends against an abrupt discontinuation, not against every
discontinuation. A program that matches an event must also
match the qualifiers of that event.

Every other shape of these patterns rejects with class `unsupported`:

| Detail | Shape |
| --- | --- |
| `grade_shape(duplicate_dimension, S)` | a second grade of one dimension in one document |
| `preference_shape(alternative_count, S)` | an event with two or more `alternative` prepositions |
| `preference_shape(no_preferred, S)` | an event with an `alternative` preposition and no second participant |
| `preference_shape(endpoint, S)` | a preferred option or an alternative that is not a plain referent (a property, a time quantity or a frame) |
| `qualifier_shape(degree, S)` | a qualifier adverb in a comparative or superlative form, as in `more carefully` |
| `qualifier_shape(asserted, S)` | an adverb of class `usuality`, `ideality`, `possibility` or `applicability` that qualifies an asserted clause |

Annotations are data, never inference. A grade does not rank
recommendations, and a preference does not forbid the alternative or
oblige the preferred option. A qualifier sets no frequency,
probability, priority or condition. Erasing every strength annotation
from a document gives the clauses that the same sentences give without
the strength rows and without the qualifier adverbs; an annotation in a
rule antecedent adds one body goal, which a matching fact must also
carry. A question asks for a grade by its source label and for a
preference by its words; a question cannot contain an adverb. A program
queries `guideline_grade/5`, `guideline_preference/4` and
`guideline_qualifier/4` directly.

### Comparison conditions

A condition of a rule or a question compares a stated quantity with its
bound. The condition `at least 50 MME-units-per-day` is met by a fact
that states `exactly 60`, `60`, `at least 60` or `more than 50`. It is not
met by `at most 70`, `about 60` or a quantity without a number. A condition
is met when every value that the stated quantity allows is a value that
the condition allows. A plain number allows that count or more, `exactly`
allows the count alone, `geq` and `leq` include their bound, and `greater`
and `less` exclude it. Counts are integers, and the comparison treats the
values between them as possible. The comparison is therefore safe and can
miss an entailment that holds only for whole counts: `more than 49` does
not meet `at least 50`.

The compiler converts each body object whose comparison is `exactly`,
`geq`, `greater`, `leq` or `less`. The object keeps its cardinality
literal with two new variables, and the built-in compares them with the
bound:

```
guideline_entity(actual,B,'MME-unit-per-day',countable),
guideline_cardinality(actual,B,na,C,D), guideline_satisfies(C,D,geq,50)
```

A plain-number condition (`eq`), an `about` condition, a quantity without
a number, every rule head and every root fact keep their literals as data.

A time quantity carries its unit in the annotation
`guideline_unit(Context, Quantity, Unit)` wherever it appears, when the
guideline has a vocabulary table. A converted time quantity compares across
units: seconds, minutes, hours, days and weeks convert exactly, and months
convert to years at twelve to one. A day and a month never compare. The
condition leaves out the entity literal of the quantity, because the noun
of a time quantity names its unit, and the unit slots of the annotations
that name the quantity share one variable:

```
guideline_cardinality(actual,F,na,G,H), guideline_unit(actual,F,I),
guideline_satisfies(G,H,I,greater,3,day)
```

A fact `exactly 1 week` meets this condition. A fact `exactly 1 month`
does not.

The built-ins are no document predicates. No clause heads them, and no
declaration names them. The verified engine evaluates them, and
`guidelines/schema.pl` states them in ISO Prolog for other engines. An
engine gives exact results when its integers can hold each count
multiplied by 604800, the number of seconds in one week. SWI-Prolog
9.2.9 has unbounded integers. A consumer loads that file with the
documents. `ckc compile` writes the
file, `ckc check` rejects a missing or stale copy, and the release
archive ships it. A built-in call with an argument of another shape
fails and raises no error.

A program that matches patient data states each value as a fact. A
measured value takes `exactly`, as a quantity without a comparator does in
FHIR. A reported bound takes `geq`, `greater`, `leq` or `less`. Each time
quantity also takes its `guideline_unit` literal. ACE root facts cannot
state an exact value, because an upper bound at the root of a sentence
rejects. A ranged minimum (`guideline_range/3`) states an uncertain
minimum, not an interval of values: its upper end and every count-per-
period period keep exact matching. An `about` quantity carries no
tolerance and meets no comparison.

### Question projection

The compiler's `question` mode compiles one ACE question against the
same vocabulary (`ckc queries` stages the APE tree and runs it):

```sh
swipl -q -f none -F none -s <ape-tree-dir>/prolog/ace_to_pl.pl -g main \
  -t 'halt(9)' -- question <ape-tree-dir> <qid> <vocabulary.tsv | -> <ulex | ->   # ACE on stdin
```

The input must be exactly one sentence line that parses to one root
question box. `<qid>` follows the docid grammar. Success emits four
lines. Line 1 is a generated-file comment. Line 2 is the ground
`'$guideline_query'(v1, Qid, ace_sha256(H), ulex(none | sha256(U)), vocabulary(none | sha256(T)))`
record. Line 3 is a `% Q1:` comment with the verbatim sentence. Line 4
is one `'$guideline_query_projection'(goal(Conj), answers(Manifest))`
term. `Conj` is an explicit `','/2` conjunction of goals rendered
through the rule-antecedent pipeline. The root context is `actual`,
and referents stay variables. A modal box contributes its
`guideline_operator/3` edge before its payload goals, under a shared
existential context variable. `Manifest` lists one `answer(Var, Desc)`
row per wh-placeholder in source order. `Desc` is `noun(Noun, Class)`
when exactly one same-box `object/6` types the placeholder; otherwise
it is `wh(who)` or `wh(what)`. Goal and manifest share variables
inside the one projection term.

A question of a guideline with `vocabulary.tsv` compiles with the
table, and its record carries the table digest. With a table, a
question admits three more shapes. It admits the condition list of an
upper-bounding determiner and flattens that list into its box; a
placeholder inside such a list rejects as `condition_shape`. It admits
`relation/3` conditions. It runs the pattern pass of the section
"Vocabulary table and time annotations" over its goals, with the same
rejects. An `of` link that no pattern consumes rejects. Without a
table, a question admits none of these shapes.

Supported forms: `wh(who | which | what)` and yes-no questions over
conjunctive content, with modal boxes at any nesting of themselves.
Structural and blocker failures reject with class `unsupported` and
exit 1. `query_expected(S)` means that no root question exists.
`query_sentences(N)` means that the input is not exactly one sentence.
`query_unsupported(Blocker, S)` names a blocking construct. Blockers
are `universal`, `disjunction`, `classical_negation`, `naf`, and the
unsupported tags `wh(howm | how | where | when)`. A foreign leaf
rejects as `leaf(Name/Arity)`; a malformed placeholder rejects as
`marker(_)`. Inherited
parser, input, and load failures keep their own classes, details, and
exit codes. The projection emits no document
indicators, no declarations, and no proof obligations. It never
enters a document, aggregate-check, or recursion-check composition.
`ckc check` re-derives every committed query separately and compares
the bytes.

### Query answers

`ckc v1 answer` solves one compiled query against a loaded
composition in the verified Rust engine:

```sh
ckc v1 answer <manifest> <query-pl>
```

`<manifest>` uses the aggregate manifest grammar. The payload column
must name readable files, and the mode never parses payload terms. A
0-byte manifest is the empty composition: the mode still declares the
indicators and solves against no clauses. `<query-pl>` must read
as exactly two terms in order: the ground `'$guideline_query'/5`
record, then the `'$guideline_query_projection'/2` term. A query names
any of the 17 semantic predicates and the comparison built-ins, and it
runs against any composition. The mode
reads the query file as data and never consults it. The file must hold the exact canonical bytes that `ckc queries` writes: an added comment or a layout change rejects as `query_file(noncanonical)`.

Success emits a two-line artifact on stdout: a generated-file
comment, then one ground term
`'$guideline_answers'(v1, Qid, query_sha256(H), result(R))`. `H` is
the SHA-256 of the raw query-file bytes. The solver runs under fixed
bounds: depth 100 for each derivation, one 100000-inference budget
that is cumulative across backtracking for the whole query, and
1000000 inferences for the whole run. For a wh query (`answers` rows
present), `R` is `solutions(Sols)`, or `indeterminate(limit)` when a
bound trips. Each distinct solution contributes one `sol(Values)`
row; rows follow the standard order of terms, and values follow the
answer-manifest order. For a yes-no query
(`answers([])`), the first proof is conclusive. `R` is `yes` when a proof is found, `no(finite_failure)` when the search ends without a proof and without a tripped bound, and `indeterminate(limit)` when it ends without a proof after a bound tripped. Inside a negated goal, a bound that cuts the inner search counts as the inner goal's failure, so the negation can succeed and the query can answer `yes`. A nonground solution rejects
with class `proof` as `nonground_solution(Qid)`. A malformed query
file rejects with class `check_load` as `query_file(<why>)`. Manifest
and composition load failures keep the aggregate classes and details.

The engine searches depth-first and tries clauses in file order. It
runs the leftmost goal first, with one exception. An operator goal
`guideline_operator(Outer, Inner, Op)` waits when `Inner` is still a
variable and a later goal names that variable as its first argument.
Such a later goal is part of the box content, so its result binds the
box context. A comparison built-in never names a box context, and one
whose arguments are not bound yet ends the run as a negation does, so a
waiting operator goal never lets a comparison run before its values.
Only the goals before the next negation-as-failure goal
count, and a conjunction counts with its parts. The engine runs the
leftmost goal that does not wait. The clause body that resolves this
goal takes its place, so the waiting operator goal runs directly after
the head unification that binds its context. A rule whose consequent
box is a different box therefore fails before its body runs. The same
rule applies to the goals of a question.

A goal never moves past a negation. A negation runs only after every
goal to its left has run, together with all goals that those goals
started. In every certified document, each variable of a negation
that also occurs outside the negation occurs in an earlier positive
goal of the same body. For such documents, each negation runs with
the same bindings as in the left-to-right order. When the search ends
in both orders, it gives the same answers. A negation in a document
that the compiler did not certify can run with more bindings than in
the left-to-right order, and it can then give a different answer. The
order of the search decides which branch a bound cuts, whether a
search ends, and which proof the engine finds first.

Each step of the search costs one inference: a call or a retry of a
goal (the clause scan and the head unification included), the split of
a conjunction, the entry into a negation, the cut that ends a
negation, a comparison built-in, a pruned goal, and a recorded solution. The step that
reports a yes-no proof costs one inference too.

The compiled Prolog keeps the body order that the compiler writes, so
a standard Prolog engine searches these documents left to right.
`recursion-check` checks the leftmost body goal, which is the first
goal of that order. The engine in this repository can run a later goal
first.

Committed query artifacts live under `guidelines/<id>/queries/`:
`<qid>.ace` sources at the root, compiled queries under `pl/`, answer
artifacts under `answers/`, and proof traces under `traces/`.
`ckc queries <id>` derives every artifact in memory and writes only
after every derivation succeeds. `check`
re-derives each file per query twice and compares the bytes. A
committed answer must be `yes` or nonempty `solutions(...)`;
committed queries stay demonstrations. The `queries` and `check`
commands bound every compile, answer, and trace subprocess at 30
seconds of wall-clock time. A run that exceeds the bound fails the
gate. The direct `ckc v1` invocation above has no process bound.

### Proof traces

`ckc v1 trace` re-proves the positive claims of one answer artifact
against a loaded composition in the verified Rust engine:

```sh
ckc v1 trace <manifest> <query-pl> <answers-pl>
```

The manifest and query file follow the answer-mode rules.
`<answers-pl>` must read as the answer artifact for the same query:
one ground `'$guideline_answers'` term. The version, qid, and query
hash must match. The result must fit the query's mode. A malformed
or mismatched answers file rejects with class `check_load` as
`answers_file(<why>)`.

Success emits a two-line artifact on stdout: a generated-file
comment, then one ground term `'$guideline_traces'(v1, Qid,
query_sha256(H), answers_sha256(A), result(R))`. `A` is the SHA-256
of the raw answers-file bytes. `R` mirrors the answer result with a
proof in place of each positive claim. `yes` becomes `yes(P)`. Each
`sol(Values)` row becomes `sol(Values, P)` in file order.
`no(finite_failure)` and `indeterminate(limit)` carry no positive
claim and stay verbatim.

`P` is `proved(Nodes)`, `unproved(finite_failure)`, or
`unproved(limit)`. Each proof node is `clause(sentence(DocId, S),
clause_sha256(Hex), Children)`. It names the resolved clause by its document and by the `% S<n>:` block that holds the clause's line. A clause that cites an earlier sentence's referent still names its own sentence. `Hex` is the SHA-256 of
that clause's rendered document line with its newline. A re-checked
negation-as-failure goal freezes as a `naf(Goal)` leaf among a
clause node's children. A comparison built-in that held freezes as a
`builtin(Goal)` leaf, the goal as called, with no clause digest. Root
nodes are clause nodes or `builtin(Goal)` leaves. The
prover is a directed first-proof interpreter over the loaded
clauses. It selects goals as the answer mode does: an operator goal
waits for its box content. The goals of a row are separate roots, and
each root keeps its place in the proof. Each row's search runs under
depth 1000 and 100000 inferences. Each materialized clause node adds
one inference to the whole run but not to its row. The whole run is bounded at 1000000 inferences. The
interpreter's depth measure is its own; it is not comparable with
the answer mode's engine measure. A negation site re-checks under
the same bounds. A negation call is safe when no variable of the
negated goal occurs in a later goal of the same search level; a
variable that occurs only inside the negation stays free. The prover
cuts an unsafe call like a tripped bound, so the row ends
`unproved(limit)` unless another branch proves it. A bound that trips inside a negation makes the row `unproved(limit)` unless the inner search still finds a proof; an inner proof absorbs the cut, the negation fails, and the row can end `unproved(finite_failure)`. When the
whole-run bound trips, the result becomes `indeterminate(limit)` in
place of the mirror. The direct `ckc v1` invocation has no process
bound.

`check` re-derives each committed trace twice, compares the bytes,
and resolves every `clause_sha256` to exactly one clause line of the
committed document under `pl/`. A committed trace must prove its
answer: `yes(proved(...))`, or solution rows that are all proved.
`check` prints one `ckc: traces <id> <n> traces; nodes=<k>` meter
per guideline beside the queries meter.

