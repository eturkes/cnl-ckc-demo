% cdc2022-opioid-rec12-imp05.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-rec12-imp05',ace_sha256('65204a580ab3ced05feab73a3b7252b45382a85964d57af6548fb07827710d26'),ulex(sha256('3e37dcfbb36dbdd0830d644235c88914b28def633a7ac43d2b5bb53faf8ba507')),vocabulary(sha256('9d7632637554f8cbfe72e7d34a9b9d14c29eb8593aebb1c128a870c5dcf77ead'))).
% S1: If a clinician identifies an opioid-use-disorder in a patient then the clinician may initiate an opioid-use-disorder-intervention for the patient.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec12-imp05',1,box(1),[A,B,C,D]),may) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,identify), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,in,C).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',1,ref(5),[A,B,C,D]),'opioid-use-disorder-intervention',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,identify), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,in,C).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',1,ref(5),[A,B,C,D]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,identify), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,in,C).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',1,ref(6),[A,B,C,D]),initiate) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,identify), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,in,C).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',1,ref(6),[A,B,C,D]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,identify), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,in,C).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',1,ref(6),[A,B,C,D]),2,'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',1,ref(5),[A,B,C,D])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,identify), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,in,C).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',1,ref(6),[A,B,C,D]),for,C) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,identify), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,in,C).
% S2: Every opioid-use-disorder-intervention may save a life.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec12-imp05',2,box(1),[A]),may) :- guideline_entity(actual,A,'opioid-use-disorder-intervention',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',2,ref(2),[A]),life,countable) :- guideline_entity(actual,A,'opioid-use-disorder-intervention',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',2,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'opioid-use-disorder-intervention',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',2,ref(3),[A]),save) :- guideline_entity(actual,A,'opioid-use-disorder-intervention',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',2,ref(3),[A]),1,A) :- guideline_entity(actual,A,'opioid-use-disorder-intervention',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',2,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',2,ref(2),[A])) :- guideline_entity(actual,A,'opioid-use-disorder-intervention',countable), guideline_cardinality(actual,A,na,eq,1).
% S3: If a clinician identifies an opioid-use-disorder in a patient then the clinician should conduct a patient-safety-collaboration with the patient.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec12-imp05',3,box(1),[A,B,C,D]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,identify), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,in,C).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',3,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',3,ref(5),[A,B,C,D]),'patient-safety-collaboration',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,identify), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,in,C).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',3,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',3,ref(5),[A,B,C,D]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,identify), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,in,C).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',3,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',3,ref(6),[A,B,C,D]),conduct) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,identify), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,in,C).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',3,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',3,ref(6),[A,B,C,D]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,identify), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,in,C).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',3,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',3,ref(6),[A,B,C,D]),2,'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',3,ref(5),[A,B,C,D])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,identify), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,in,C).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',3,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',3,ref(6),[A,B,C,D]),with,C) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,identify), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,in,C).
% S4: Every patient-safety-collaboration may increase a successful-treatment-likelihood.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec12-imp05',4,box(1),[A]),may) :- guideline_entity(actual,A,'patient-safety-collaboration',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',4,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',4,ref(2),[A]),'successful-treatment-likelihood',countable) :- guideline_entity(actual,A,'patient-safety-collaboration',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',4,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',4,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'patient-safety-collaboration',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',4,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',4,ref(3),[A]),increase) :- guideline_entity(actual,A,'patient-safety-collaboration',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',4,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',4,ref(3),[A]),1,A) :- guideline_entity(actual,A,'patient-safety-collaboration',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec12-imp05',4,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',4,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec12-imp05',4,ref(2),[A])) :- guideline_entity(actual,A,'patient-safety-collaboration',countable), guideline_cardinality(actual,A,na,eq,1).
