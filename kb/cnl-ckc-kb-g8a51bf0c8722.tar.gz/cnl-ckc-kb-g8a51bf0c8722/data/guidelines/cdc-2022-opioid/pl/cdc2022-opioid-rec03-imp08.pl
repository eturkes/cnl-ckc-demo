% cdc2022-opioid-rec03-imp08.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-rec03-imp08',ace_sha256('615cd79b630acda2a5d1c01c0b5b334efe6520573fbbe80a35a28e072042f741'),ulex(sha256('3e37dcfbb36dbdd0830d644235c88914b28def633a7ac43d2b5bb53faf8ba507')),vocabulary(sha256('9d7632637554f8cbfe72e7d34a9b9d14c29eb8593aebb1c128a870c5dcf77ead'))).
% S1: If a clinician does not understand a transdermal-fentanyl-dosing then it is recommended that the clinician does not consider a transdermal-fentanyl-prescription.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec03-imp08',1,box(2),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'transdermal-fentanyl-dosing',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,understand), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
guideline_operator('$guideline_id'(context,'cdc2022-opioid-rec03-imp08',1,box(2),[A]),'$guideline_id'(context,'cdc2022-opioid-rec03-imp08',1,box(3),[A]),-) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'transdermal-fentanyl-dosing',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,understand), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec03-imp08',1,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec03-imp08',1,ref(4),[A]),'transdermal-fentanyl-prescription',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'transdermal-fentanyl-dosing',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,understand), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec03-imp08',1,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec03-imp08',1,ref(4),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'transdermal-fentanyl-dosing',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,understand), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec03-imp08',1,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec03-imp08',1,ref(5),[A]),consider) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'transdermal-fentanyl-dosing',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,understand), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec03-imp08',1,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec03-imp08',1,ref(5),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'transdermal-fentanyl-dosing',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,understand), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec03-imp08',1,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec03-imp08',1,ref(5),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec03-imp08',1,ref(4),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'transdermal-fentanyl-dosing',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,understand), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
% S2: If a clinician does not understand a transdermal-fentanyl-absorption then it is recommended that the clinician does not consider a transdermal-fentanyl-prescription.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec03-imp08',2,box(2),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'transdermal-fentanyl-absorption',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,understand), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
guideline_operator('$guideline_id'(context,'cdc2022-opioid-rec03-imp08',2,box(2),[A]),'$guideline_id'(context,'cdc2022-opioid-rec03-imp08',2,box(3),[A]),-) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'transdermal-fentanyl-absorption',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,understand), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec03-imp08',2,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec03-imp08',2,ref(4),[A]),'transdermal-fentanyl-prescription',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'transdermal-fentanyl-absorption',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,understand), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec03-imp08',2,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec03-imp08',2,ref(4),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'transdermal-fentanyl-absorption',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,understand), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec03-imp08',2,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec03-imp08',2,ref(5),[A]),consider) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'transdermal-fentanyl-absorption',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,understand), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec03-imp08',2,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec03-imp08',2,ref(5),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'transdermal-fentanyl-absorption',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,understand), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec03-imp08',2,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec03-imp08',2,ref(5),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec03-imp08',2,ref(4),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'transdermal-fentanyl-absorption',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,understand), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
% S3: If a clinician does not prepare a patient-education then it is recommended that the clinician does not consider a transdermal-fentanyl-prescription.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec03-imp08',3,box(2),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'patient-education',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,prepare), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
guideline_operator('$guideline_id'(context,'cdc2022-opioid-rec03-imp08',3,box(2),[A]),'$guideline_id'(context,'cdc2022-opioid-rec03-imp08',3,box(3),[A]),-) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'patient-education',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,prepare), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec03-imp08',3,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec03-imp08',3,ref(4),[A]),'transdermal-fentanyl-prescription',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'patient-education',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,prepare), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec03-imp08',3,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec03-imp08',3,ref(4),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'patient-education',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,prepare), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec03-imp08',3,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec03-imp08',3,ref(5),[A]),consider) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'patient-education',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,prepare), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec03-imp08',3,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec03-imp08',3,ref(5),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'patient-education',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,prepare), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec03-imp08',3,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec03-imp08',3,ref(5),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec03-imp08',3,ref(4),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_operator(actual,B,-), guideline_entity(B,C,'patient-education',countable), guideline_cardinality(B,C,na,eq,1), guideline_event(B,D,prepare), guideline_arg(B,D,1,A), guideline_arg(B,D,2,C).
