% cdc2022-opioid-s22-11.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-s22-11',ace_sha256(bed13f5c554d41f56a31f7ba540798ce461dce3797d43ce6c223554086524bb7),ulex(sha256('3e37dcfbb36dbdd0830d644235c88914b28def633a7ac43d2b5bb53faf8ba507')),vocabulary(sha256('9d7632637554f8cbfe72e7d34a9b9d14c29eb8593aebb1c128a870c5dcf77ead'))).
% S1: A patient-education is critical before an outpatient-opioid-therapy.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',1,ref(1),[]),'patient-education',countable).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',1,ref(1),[]),na,eq,1).
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',1,ref(2),[]),'outpatient-opioid-therapy',countable).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',1,ref(2),[]),na,eq,1).
guideline_property(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',1,ref(3),[]),critical,pos).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',1,ref(4),[]),be).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',1,ref(4),[]),1,'$guideline_id'(product,'cdc2022-opioid-s22-11',1,ref(1),[])).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',1,ref(4),[]),2,'$guideline_id'(product,'cdc2022-opioid-s22-11',1,ref(3),[])).
guideline_pp(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',1,ref(4),[]),before,'$guideline_id'(product,'cdc2022-opioid-s22-11',1,ref(2),[])).
guideline_order(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',1,ref(4),[]),before,'$guideline_id'(product,'cdc2022-opioid-s22-11',1,ref(2),[])).
% S2: A patient-discussion is critical before an outpatient-opioid-therapy.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',2,ref(1),[]),'patient-discussion',countable).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',2,ref(1),[]),na,eq,1).
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',2,ref(2),[]),'outpatient-opioid-therapy',countable).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',2,ref(2),[]),na,eq,1).
guideline_property(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',2,ref(3),[]),critical,pos).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',2,ref(4),[]),be).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',2,ref(4),[]),1,'$guideline_id'(product,'cdc2022-opioid-s22-11',2,ref(1),[])).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',2,ref(4),[]),2,'$guideline_id'(product,'cdc2022-opioid-s22-11',2,ref(3),[])).
guideline_pp(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',2,ref(4),[]),before,'$guideline_id'(product,'cdc2022-opioid-s22-11',2,ref(2),[])).
guideline_order(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',2,ref(4),[]),before,'$guideline_id'(product,'cdc2022-opioid-s22-11',2,ref(2),[])).
% S3: A patient-preference can inform a clinical-decision.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',3,ref(1),[]),'patient-preference',countable).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',3,ref(1),[]),na,eq,1).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s22-11',3,box(1),[]),can).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s22-11',3,box(1),[]),'$guideline_id'(product,'cdc2022-opioid-s22-11',3,ref(2),[]),'clinical-decision',countable).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s22-11',3,box(1),[]),'$guideline_id'(product,'cdc2022-opioid-s22-11',3,ref(2),[]),na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s22-11',3,box(1),[]),'$guideline_id'(product,'cdc2022-opioid-s22-11',3,ref(3),[]),inform).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s22-11',3,box(1),[]),'$guideline_id'(product,'cdc2022-opioid-s22-11',3,ref(3),[]),1,'$guideline_id'(product,'cdc2022-opioid-s22-11',3,ref(1),[])).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s22-11',3,box(1),[]),'$guideline_id'(product,'cdc2022-opioid-s22-11',3,ref(3),[]),2,'$guideline_id'(product,'cdc2022-opioid-s22-11',3,ref(2),[])).
% S4: A patient-value can inform a clinical-decision.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',4,ref(1),[]),'patient-value',countable).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s22-11',4,ref(1),[]),na,eq,1).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s22-11',4,box(1),[]),can).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s22-11',4,box(1),[]),'$guideline_id'(product,'cdc2022-opioid-s22-11',4,ref(2),[]),'clinical-decision',countable).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s22-11',4,box(1),[]),'$guideline_id'(product,'cdc2022-opioid-s22-11',4,ref(2),[]),na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s22-11',4,box(1),[]),'$guideline_id'(product,'cdc2022-opioid-s22-11',4,ref(3),[]),inform).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s22-11',4,box(1),[]),'$guideline_id'(product,'cdc2022-opioid-s22-11',4,ref(3),[]),1,'$guideline_id'(product,'cdc2022-opioid-s22-11',4,ref(1),[])).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s22-11',4,box(1),[]),'$guideline_id'(product,'cdc2022-opioid-s22-11',4,ref(3),[]),2,'$guideline_id'(product,'cdc2022-opioid-s22-11',4,ref(2),[])).
