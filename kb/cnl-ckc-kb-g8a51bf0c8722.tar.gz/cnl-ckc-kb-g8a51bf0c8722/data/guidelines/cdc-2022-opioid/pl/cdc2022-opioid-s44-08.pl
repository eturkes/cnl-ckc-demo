% cdc2022-opioid-s44-08.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-s44-08',ace_sha256(a16c2933453bdbc3124349a123cacf6a60a3ba6146ff51043b6ae3d653831d41),ulex(sha256('3e37dcfbb36dbdd0830d644235c88914b28def633a7ac43d2b5bb53faf8ba507')),vocabulary(sha256('9d7632637554f8cbfe72e7d34a9b9d14c29eb8593aebb1c128a870c5dcf77ead'))).
% S1: Every clinician should reassess a patient-pain and should reassess a patient-function and should reassess a treatment-course.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s44-08',1,box(1),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s44-08',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',1,ref(2),[A]),'patient-pain',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s44-08',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',1,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s44-08',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',1,ref(3),[A]),reassess) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s44-08',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',1,ref(3),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s44-08',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',1,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s44-08',1,ref(2),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s44-08',1,box(2),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s44-08',1,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',1,ref(4),[A]),'patient-function',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s44-08',1,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',1,ref(4),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s44-08',1,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',1,ref(5),[A]),reassess) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s44-08',1,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',1,ref(5),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s44-08',1,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',1,ref(5),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s44-08',1,ref(4),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s44-08',1,box(3),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s44-08',1,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',1,ref(6),[A]),'treatment-course',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s44-08',1,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',1,ref(6),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s44-08',1,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',1,ref(7),[A]),reassess) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s44-08',1,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',1,ref(7),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s44-08',1,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',1,ref(7),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s44-08',1,ref(6),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
% S2: Every clinician should address a potentially-reversible-chronic-pain-cause.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s44-08',2,box(1),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s44-08',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',2,ref(2),[A]),'potentially-reversible-chronic-pain-cause',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s44-08',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',2,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s44-08',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',2,ref(3),[A]),address) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s44-08',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',2,ref(3),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s44-08',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s44-08',2,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s44-08',2,ref(2),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
% S3: If a pain-management-optimization is needed for a patient then every clinician should optimize a pain-management for the patient.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s44-08',3,box(1),[A,B,C,D,E]),should) :- guideline_entity(actual,A,'pain-management-optimization',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_property(actual,C,needed,pos), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_qualifier(actual,D,applicability,needed), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s44-08',3,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-s44-08',3,ref(6),[A,B,C,D,E]),'pain-management',countable) :- guideline_entity(actual,A,'pain-management-optimization',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_property(actual,C,needed,pos), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_qualifier(actual,D,applicability,needed), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s44-08',3,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-s44-08',3,ref(6),[A,B,C,D,E]),na,eq,1) :- guideline_entity(actual,A,'pain-management-optimization',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_property(actual,C,needed,pos), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_qualifier(actual,D,applicability,needed), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s44-08',3,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-s44-08',3,ref(7),[A,B,C,D,E]),optimize) :- guideline_entity(actual,A,'pain-management-optimization',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_property(actual,C,needed,pos), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_qualifier(actual,D,applicability,needed), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s44-08',3,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-s44-08',3,ref(7),[A,B,C,D,E]),1,E) :- guideline_entity(actual,A,'pain-management-optimization',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_property(actual,C,needed,pos), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_qualifier(actual,D,applicability,needed), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s44-08',3,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-s44-08',3,ref(7),[A,B,C,D,E]),2,'$guideline_id'(product,'cdc2022-opioid-s44-08',3,ref(6),[A,B,C,D,E])) :- guideline_entity(actual,A,'pain-management-optimization',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_property(actual,C,needed,pos), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_qualifier(actual,D,applicability,needed), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s44-08',3,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-s44-08',3,ref(7),[A,B,C,D,E]),for,B) :- guideline_entity(actual,A,'pain-management-optimization',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_property(actual,C,needed,pos), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_qualifier(actual,D,applicability,needed), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
