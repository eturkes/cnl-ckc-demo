% cdc2022-opioid-s6-02.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-s6-02',ace_sha256('308189cdaa04e1d925fa7fb1bcab7e1e323a01f15c8409ae1a0488dcbce6c9cc'),ulex(sha256('3e37dcfbb36dbdd0830d644235c88914b28def633a7ac43d2b5bb53faf8ba507')),vocabulary(sha256('9d7632637554f8cbfe72e7d34a9b9d14c29eb8593aebb1c128a870c5dcf77ead'))).
% S1: Every clinician should consider a recommendation during a clinician-patient-relationship.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s6-02',1,box(1),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s6-02',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',1,ref(2),[A]),recommendation,countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s6-02',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',1,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s6-02',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',1,ref(3),[A]),'clinician-patient-relationship',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s6-02',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',1,ref(3),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s6-02',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',1,ref(4),[A]),consider) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',1,ref(4),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',1,ref(4),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s6-02',1,ref(2),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s6-02',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',1,ref(4),[A]),during,'$guideline_id'(product,'cdc2022-opioid-s6-02',1,ref(3),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
% S2: Every clinician-patient-relationship should have a shared-understanding.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s6-02',2,box(1),[A]),should) :- guideline_entity(actual,A,'clinician-patient-relationship',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s6-02',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',2,ref(2),[A]),'shared-understanding',countable) :- guideline_entity(actual,A,'clinician-patient-relationship',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s6-02',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',2,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'clinician-patient-relationship',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s6-02',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',2,ref(3),[A]),have) :- guideline_entity(actual,A,'clinician-patient-relationship',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',2,ref(3),[A]),1,A) :- guideline_entity(actual,A,'clinician-patient-relationship',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',2,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s6-02',2,ref(2),[A])) :- guideline_entity(actual,A,'clinician-patient-relationship',countable), guideline_cardinality(actual,A,na,eq,1).
% S3: Every clinician should consider a recommendation during a whole-person-approach.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s6-02',3,box(1),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s6-02',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',3,ref(2),[A]),recommendation,countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s6-02',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',3,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s6-02',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',3,ref(3),[A]),'whole-person-approach',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s6-02',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',3,ref(3),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s6-02',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',3,ref(4),[A]),consider) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',3,ref(4),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',3,ref(4),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s6-02',3,ref(2),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s6-02',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',3,ref(4),[A]),during,'$guideline_id'(product,'cdc2022-opioid-s6-02',3,ref(3),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
% S4: Every whole-person-approach should consider a physical-functioning and should consider a psychological-functioning.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s6-02',4,box(1),[A]),should) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s6-02',4,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',4,ref(2),[A]),'physical-functioning',countable) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s6-02',4,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',4,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s6-02',4,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',4,ref(3),[A]),consider) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',4,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',4,ref(3),[A]),1,A) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',4,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',4,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s6-02',4,ref(2),[A])) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s6-02',4,box(2),[A]),should) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s6-02',4,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',4,ref(4),[A]),'psychological-functioning',countable) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s6-02',4,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',4,ref(4),[A]),na,eq,1) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s6-02',4,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',4,ref(5),[A]),consider) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',4,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',4,ref(5),[A]),1,A) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',4,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',4,ref(5),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s6-02',4,ref(4),[A])) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
% S5: Every whole-person-approach should consider a support-need and should consider an expected-health-outcome and should consider a well-being.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s6-02',5,box(1),[A]),should) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s6-02',5,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',5,ref(2),[A]),'support-need',countable) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s6-02',5,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',5,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s6-02',5,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',5,ref(3),[A]),consider) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',5,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',5,ref(3),[A]),1,A) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',5,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',5,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s6-02',5,ref(2),[A])) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s6-02',5,box(2),[A]),should) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s6-02',5,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',5,ref(4),[A]),'expected-health-outcome',countable) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s6-02',5,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',5,ref(4),[A]),na,eq,1) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s6-02',5,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',5,ref(5),[A]),consider) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',5,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',5,ref(5),[A]),1,A) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',5,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',5,ref(5),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s6-02',5,ref(4),[A])) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s6-02',5,box(3),[A]),should) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s6-02',5,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',5,ref(6),[A]),'well-being',countable) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s6-02',5,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',5,ref(6),[A]),na,eq,1) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s6-02',5,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',5,ref(7),[A]),consider) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',5,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',5,ref(7),[A]),1,A) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',5,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',5,ref(7),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s6-02',5,ref(6),[A])) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
% S6: Every whole-person-approach should consider a home-environment and should consider a home-responsibility and should consider a work-responsibility.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s6-02',6,box(1),[A]),should) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s6-02',6,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',6,ref(2),[A]),'home-environment',countable) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s6-02',6,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',6,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s6-02',6,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',6,ref(3),[A]),consider) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',6,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',6,ref(3),[A]),1,A) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',6,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',6,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s6-02',6,ref(2),[A])) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s6-02',6,box(2),[A]),should) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s6-02',6,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',6,ref(4),[A]),'home-responsibility',countable) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s6-02',6,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',6,ref(4),[A]),na,eq,1) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s6-02',6,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',6,ref(5),[A]),consider) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',6,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',6,ref(5),[A]),1,A) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',6,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',6,ref(5),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s6-02',6,ref(4),[A])) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s6-02',6,box(3),[A]),should) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s6-02',6,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',6,ref(6),[A]),'work-responsibility',countable) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s6-02',6,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',6,ref(6),[A]),na,eq,1) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s6-02',6,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',6,ref(7),[A]),consider) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',6,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',6,ref(7),[A]),1,A) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s6-02',6,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-s6-02',6,ref(7),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s6-02',6,ref(6),[A])) :- guideline_entity(actual,A,'whole-person-approach',countable), guideline_cardinality(actual,A,na,eq,1).
