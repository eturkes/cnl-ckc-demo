% cdc2022-opioid-rec07-imp10.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
:- multifile(guideline_exclusion/1).
:- discontiguous(guideline_exclusion/1).
:- multifile(guideline_supersession/4).
:- discontiguous(guideline_supersession/4).
:- multifile(guideline_evaluation_date/1).
:- discontiguous(guideline_evaluation_date/1).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-rec07-imp10',ace_sha256('398696a147ff8b4962176d048d759bf196b3e9a1d31c56a5fd906c520a452a4d'),ulex(sha256(fba48e003101de64df33400ab2595fa7589360ac19f4c77ac3d17bd085f5b8c0)),vocabulary(sha256('335c132fd0e3d3163ba40c255e7db41eecc36492d8098263c505b17f44bbef5a'))).
% S1: If a person is a patient then every clinician may ensure an affordable-follow-up-evaluation-access for the person.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec07-imp10',1,box(1),[A,B,C,D]),may) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,clinician,countable), guideline_cardinality(actual,D,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec07-imp10',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',1,ref(5),[A,B,C,D]),'affordable-follow-up-evaluation-access',countable) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,clinician,countable), guideline_cardinality(actual,D,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec07-imp10',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',1,ref(5),[A,B,C,D]),na,eq,1) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,clinician,countable), guideline_cardinality(actual,D,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec07-imp10',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',1,ref(6),[A,B,C,D]),ensure) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,clinician,countable), guideline_cardinality(actual,D,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec07-imp10',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',1,ref(6),[A,B,C,D]),1,D) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,clinician,countable), guideline_cardinality(actual,D,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec07-imp10',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',1,ref(6),[A,B,C,D]),2,'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',1,ref(5),[A,B,C,D])) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,clinician,countable), guideline_cardinality(actual,D,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-rec07-imp10',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',1,ref(6),[A,B,C,D]),for,A) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,clinician,countable), guideline_cardinality(actual,D,na,eq,1).
% S2: If a person is a patient then every clinical-practice-organization may ensure an affordable-follow-up-evaluation-access for the person.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec07-imp10',2,box(1),[A,B,C,D]),may) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'clinical-practice-organization',countable), guideline_cardinality(actual,D,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec07-imp10',2,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',2,ref(5),[A,B,C,D]),'affordable-follow-up-evaluation-access',countable) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'clinical-practice-organization',countable), guideline_cardinality(actual,D,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec07-imp10',2,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',2,ref(5),[A,B,C,D]),na,eq,1) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'clinical-practice-organization',countable), guideline_cardinality(actual,D,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec07-imp10',2,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',2,ref(6),[A,B,C,D]),ensure) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'clinical-practice-organization',countable), guideline_cardinality(actual,D,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec07-imp10',2,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',2,ref(6),[A,B,C,D]),1,D) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'clinical-practice-organization',countable), guideline_cardinality(actual,D,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec07-imp10',2,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',2,ref(6),[A,B,C,D]),2,'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',2,ref(5),[A,B,C,D])) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'clinical-practice-organization',countable), guideline_cardinality(actual,D,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-rec07-imp10',2,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',2,ref(6),[A,B,C,D]),for,A) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'clinical-practice-organization',countable), guideline_cardinality(actual,D,na,eq,1).
% S3: If a person is a patient then every health-system may ensure an affordable-follow-up-evaluation-access for the person.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec07-imp10',3,box(1),[A,B,C,D]),may) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'health-system',countable), guideline_cardinality(actual,D,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec07-imp10',3,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',3,ref(5),[A,B,C,D]),'affordable-follow-up-evaluation-access',countable) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'health-system',countable), guideline_cardinality(actual,D,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec07-imp10',3,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',3,ref(5),[A,B,C,D]),na,eq,1) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'health-system',countable), guideline_cardinality(actual,D,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec07-imp10',3,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',3,ref(6),[A,B,C,D]),ensure) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'health-system',countable), guideline_cardinality(actual,D,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec07-imp10',3,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',3,ref(6),[A,B,C,D]),1,D) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'health-system',countable), guideline_cardinality(actual,D,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec07-imp10',3,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',3,ref(6),[A,B,C,D]),2,'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',3,ref(5),[A,B,C,D])) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'health-system',countable), guideline_cardinality(actual,D,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-rec07-imp10',3,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec07-imp10',3,ref(6),[A,B,C,D]),for,A) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,be), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'health-system',countable), guideline_cardinality(actual,D,na,eq,1).
