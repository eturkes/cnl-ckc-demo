% cdc2022-opioid-rec04-imp01.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
:- multifile(guideline_exclusion/1).
:- discontiguous(guideline_exclusion/1).
:- multifile(guideline_supersession/4).
:- discontiguous(guideline_supersession/4).
:- multifile(guideline_evaluation_date/1).
:- discontiguous(guideline_evaluation_date/1).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-rec04-imp01',ace_sha256(a377229880b73177db24156c98612819c64b0747fd0ede083c2e99f4a530dd87),ulex(sha256(fba48e003101de64df33400ab2595fa7589360ac19f4c77ac3d17bd085f5b8c0)),vocabulary(sha256('335c132fd0e3d3163ba40c255e7db41eecc36492d8098263c505b17f44bbef5a'))).
% S1: Every opioid-dosage-recommendation is not an inflexible-standard.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec04-imp01',1,box(1),[A]),-) :- guideline_entity(actual,A,'opioid-dosage-recommendation',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec04-imp01',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',1,ref(2),[A]),'inflexible-standard',countable) :- guideline_entity(actual,A,'opioid-dosage-recommendation',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec04-imp01',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',1,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'opioid-dosage-recommendation',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec04-imp01',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',1,ref(3),[A]),be) :- guideline_entity(actual,A,'opioid-dosage-recommendation',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec04-imp01',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',1,ref(3),[A]),1,A) :- guideline_entity(actual,A,'opioid-dosage-recommendation',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec04-imp01',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',1,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',1,ref(2),[A])) :- guideline_entity(actual,A,'opioid-dosage-recommendation',countable), guideline_cardinality(actual,A,na,eq,1).
% S2: Every opioid-dosage-recommendation is not a rigid-standard.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec04-imp01',2,box(1),[A]),-) :- guideline_entity(actual,A,'opioid-dosage-recommendation',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec04-imp01',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',2,ref(2),[A]),'rigid-standard',countable) :- guideline_entity(actual,A,'opioid-dosage-recommendation',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec04-imp01',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',2,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'opioid-dosage-recommendation',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec04-imp01',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',2,ref(3),[A]),be) :- guideline_entity(actual,A,'opioid-dosage-recommendation',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec04-imp01',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',2,ref(3),[A]),1,A) :- guideline_entity(actual,A,'opioid-dosage-recommendation',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec04-imp01',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',2,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',2,ref(2),[A])) :- guideline_entity(actual,A,'opioid-dosage-recommendation',countable), guideline_cardinality(actual,A,na,eq,1).
% S3: Every opioid-dosage-recommendation is a decision-guidepost.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',3,ref(2),[A]),'decision-guidepost',countable) :- guideline_entity(actual,A,'opioid-dosage-recommendation',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',3,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'opioid-dosage-recommendation',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',3,ref(3),[A]),be) :- guideline_entity(actual,A,'opioid-dosage-recommendation',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',3,ref(3),[A]),1,A) :- guideline_entity(actual,A,'opioid-dosage-recommendation',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',3,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',3,ref(2),[A])) :- guideline_entity(actual,A,'opioid-dosage-recommendation',countable), guideline_cardinality(actual,A,na,eq,1).
% S4: A decision-guidepost can inform a clinician-patient-decision.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',4,ref(1),[]),'decision-guidepost',countable).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',4,ref(1),[]),na,eq,1).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec04-imp01',4,box(1),[]),can).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec04-imp01',4,box(1),[]),'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',4,ref(2),[]),'clinician-patient-decision',countable).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec04-imp01',4,box(1),[]),'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',4,ref(2),[]),na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec04-imp01',4,box(1),[]),'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',4,ref(3),[]),inform).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec04-imp01',4,box(1),[]),'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',4,ref(3),[]),1,'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',4,ref(1),[])).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec04-imp01',4,box(1),[]),'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',4,ref(3),[]),2,'$guideline_id'(product,'cdc2022-opioid-rec04-imp01',4,ref(2),[])).
