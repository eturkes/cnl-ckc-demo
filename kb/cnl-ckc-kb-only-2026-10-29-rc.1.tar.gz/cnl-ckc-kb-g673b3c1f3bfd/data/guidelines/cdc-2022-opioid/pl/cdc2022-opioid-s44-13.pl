% cdc2022-opioid-s44-13.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
:- multifile(guideline_exclusion/1).
:- discontiguous(guideline_exclusion/1).
:- multifile(guideline_supersession/4).
:- discontiguous(guideline_supersession/4).
:- multifile(guideline_evaluation_date/1).
:- discontiguous(guideline_evaluation_date/1).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-s44-13',ace_sha256(a6214eff9c64b0ac149432f68fecd56373204f739d648c1786830e94f55877e3),ulex(sha256(fba48e003101de64df33400ab2595fa7589360ac19f4c77ac3d17bd085f5b8c0)),vocabulary(sha256('335c132fd0e3d3163ba40c255e7db41eecc36492d8098263c505b17f44bbef5a'))).
% S1: If a clinician ensures an affordable-follow-up-evaluation-access for a patient then the clinician can minimize an unintended-patient-effect.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s44-13',1,box(1),[A,B,C,D]),can) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'affordable-follow-up-evaluation-access',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,ensure), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,for,C).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s44-13',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s44-13',1,ref(5),[A,B,C,D]),'unintended-patient-effect',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'affordable-follow-up-evaluation-access',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,ensure), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,for,C).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s44-13',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s44-13',1,ref(5),[A,B,C,D]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'affordable-follow-up-evaluation-access',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,ensure), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,for,C).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s44-13',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s44-13',1,ref(6),[A,B,C,D]),minimize) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'affordable-follow-up-evaluation-access',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,ensure), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,for,C).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s44-13',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s44-13',1,ref(6),[A,B,C,D]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'affordable-follow-up-evaluation-access',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,ensure), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,for,C).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s44-13',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s44-13',1,ref(6),[A,B,C,D]),2,'$guideline_id'(product,'cdc2022-opioid-s44-13',1,ref(5),[A,B,C,D])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'affordable-follow-up-evaluation-access',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,ensure), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,for,C).
% S2: If a clinical-practice-organization ensures an affordable-follow-up-evaluation-access for a patient then the clinical-practice-organization can minimize an unintended-patient-effect.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s44-13',2,box(1),[A,B,C,D]),can) :- guideline_entity(actual,A,'clinical-practice-organization',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'affordable-follow-up-evaluation-access',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,ensure), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,for,C).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s44-13',2,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s44-13',2,ref(5),[A,B,C,D]),'unintended-patient-effect',countable) :- guideline_entity(actual,A,'clinical-practice-organization',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'affordable-follow-up-evaluation-access',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,ensure), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,for,C).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s44-13',2,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s44-13',2,ref(5),[A,B,C,D]),na,eq,1) :- guideline_entity(actual,A,'clinical-practice-organization',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'affordable-follow-up-evaluation-access',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,ensure), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,for,C).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s44-13',2,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s44-13',2,ref(6),[A,B,C,D]),minimize) :- guideline_entity(actual,A,'clinical-practice-organization',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'affordable-follow-up-evaluation-access',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,ensure), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,for,C).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s44-13',2,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s44-13',2,ref(6),[A,B,C,D]),1,A) :- guideline_entity(actual,A,'clinical-practice-organization',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'affordable-follow-up-evaluation-access',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,ensure), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,for,C).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s44-13',2,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s44-13',2,ref(6),[A,B,C,D]),2,'$guideline_id'(product,'cdc2022-opioid-s44-13',2,ref(5),[A,B,C,D])) :- guideline_entity(actual,A,'clinical-practice-organization',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'affordable-follow-up-evaluation-access',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,ensure), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,for,C).
% S3: If a health-system ensures an affordable-follow-up-evaluation-access for a patient then the health-system can minimize an unintended-patient-effect.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s44-13',3,box(1),[A,B,C,D]),can) :- guideline_entity(actual,A,'health-system',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'affordable-follow-up-evaluation-access',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,ensure), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,for,C).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s44-13',3,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s44-13',3,ref(5),[A,B,C,D]),'unintended-patient-effect',countable) :- guideline_entity(actual,A,'health-system',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'affordable-follow-up-evaluation-access',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,ensure), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,for,C).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s44-13',3,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s44-13',3,ref(5),[A,B,C,D]),na,eq,1) :- guideline_entity(actual,A,'health-system',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'affordable-follow-up-evaluation-access',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,ensure), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,for,C).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s44-13',3,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s44-13',3,ref(6),[A,B,C,D]),minimize) :- guideline_entity(actual,A,'health-system',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'affordable-follow-up-evaluation-access',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,ensure), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,for,C).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s44-13',3,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s44-13',3,ref(6),[A,B,C,D]),1,A) :- guideline_entity(actual,A,'health-system',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'affordable-follow-up-evaluation-access',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,ensure), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,for,C).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s44-13',3,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s44-13',3,ref(6),[A,B,C,D]),2,'$guideline_id'(product,'cdc2022-opioid-s44-13',3,ref(5),[A,B,C,D])) :- guideline_entity(actual,A,'health-system',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'affordable-follow-up-evaluation-access',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,patient,countable), guideline_cardinality(actual,C,na,eq,1), guideline_event(actual,D,ensure), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,B), guideline_pp(actual,D,for,C).
