% cdc2022-opioid-rec05-imp21.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
:- multifile(guideline_exclusion/1).
:- discontiguous(guideline_exclusion/1).
:- multifile(guideline_supersession/4).
:- discontiguous(guideline_supersession/4).
:- multifile(guideline_evaluation_date/1).
:- discontiguous(guideline_evaluation_date/1).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-rec05-imp21',ace_sha256('6d75ce18151ade56634d0ff8b1230997c8c5e58f095fbe59179e7041f0a80858'),ulex(sha256(fba48e003101de64df33400ab2595fa7589360ac19f4c77ac3d17bd085f5b8c0)),vocabulary(sha256('335c132fd0e3d3163ba40c255e7db41eecc36492d8098263c505b17f44bbef5a'))).
% S1: Every clinician should screen an anxiety and should screen a depression during an opioid-taper.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec05-imp21',1,box(1),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',1,ref(2),[A]),anxiety,countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',1,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',1,ref(3),[A]),screen) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',1,ref(3),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',1,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',1,ref(2),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec05-imp21',1,box(2),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',1,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',1,ref(4),[A]),depression,countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',1,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',1,ref(4),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',1,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',1,ref(5),[A]),'opioid-taper',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',1,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',1,ref(5),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',1,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',1,ref(6),[A]),screen) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',1,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',1,ref(6),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',1,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',1,ref(6),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',1,ref(4),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',1,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',1,ref(6),[A]),during,'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',1,ref(5),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
% S2: Every clinician should screen an opioid-misuse and should screen an opioid-use-disorder during an opioid-taper.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec05-imp21',2,box(1),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',2,ref(2),[A]),'opioid-misuse',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',2,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',2,ref(3),[A]),screen) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',2,ref(3),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',2,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',2,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',2,ref(2),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec05-imp21',2,box(2),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',2,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',2,ref(4),[A]),'opioid-use-disorder',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',2,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',2,ref(4),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',2,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',2,ref(5),[A]),'opioid-taper',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',2,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',2,ref(5),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',2,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',2,ref(6),[A]),screen) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',2,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',2,ref(6),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',2,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',2,ref(6),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',2,ref(4),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',2,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',2,ref(6),[A]),during,'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',2,ref(5),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
% S3: Every clinician should vigilantly monitor an anxiety-sign and should vigilantly monitor a depression-sign during an opioid-taper.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec05-imp21',3,box(1),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',3,ref(2),[A]),'anxiety-sign',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',3,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_qualifier('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',3,ref(3),[A]),manner,vigilantly) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',3,ref(3),[A]),monitor) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',3,ref(3),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',3,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',3,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',3,ref(2),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec05-imp21',3,box(2),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',3,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',3,ref(4),[A]),'depression-sign',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',3,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',3,ref(4),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',3,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',3,ref(5),[A]),'opioid-taper',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',3,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',3,ref(5),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_qualifier('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',3,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',3,ref(6),[A]),manner,vigilantly) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',3,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',3,ref(6),[A]),monitor) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',3,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',3,ref(6),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',3,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',3,ref(6),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',3,ref(4),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',3,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',3,ref(6),[A]),during,'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',3,ref(5),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
% S4: Every clinician should vigilantly monitor an opioid-misuse-sign and should vigilantly monitor an opioid-use-disorder-sign during an opioid-taper.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec05-imp21',4,box(1),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',4,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',4,ref(2),[A]),'opioid-misuse-sign',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',4,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',4,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_qualifier('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',4,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',4,ref(3),[A]),manner,vigilantly) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',4,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',4,ref(3),[A]),monitor) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',4,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',4,ref(3),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',4,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',4,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',4,ref(2),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec05-imp21',4,box(2),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',4,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',4,ref(4),[A]),'opioid-use-disorder-sign',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',4,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',4,ref(4),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',4,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',4,ref(5),[A]),'opioid-taper',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',4,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',4,ref(5),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_qualifier('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',4,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',4,ref(6),[A]),manner,vigilantly) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',4,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',4,ref(6),[A]),monitor) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',4,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',4,ref(6),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',4,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',4,ref(6),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',4,ref(4),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',4,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',4,ref(6),[A]),during,'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',4,ref(5),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
% S5: Every opioid-taper can possibly reveal an anxiety and can possibly reveal a depression and can possibly reveal an opioid-misuse and can possibly reveal an opioid-use-disorder.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(1),[A]),can) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(2),[A]),anxiety,countable) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_qualifier('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(3),[A]),possibility,possibly) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(3),[A]),reveal) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(3),[A]),1,A) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(2),[A])) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(2),[A]),can) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(4),[A]),depression,countable) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(4),[A]),na,eq,1) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_qualifier('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(5),[A]),possibility,possibly) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(5),[A]),reveal) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(5),[A]),1,A) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(5),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(4),[A])) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(3),[A]),can) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(6),[A]),'opioid-misuse',countable) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(6),[A]),na,eq,1) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_qualifier('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(7),[A]),possibility,possibly) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(7),[A]),reveal) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(7),[A]),1,A) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(3),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(7),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(6),[A])) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(4),[A]),can) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(4),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(8),[A]),'opioid-use-disorder',countable) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(4),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(8),[A]),na,eq,1) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_qualifier('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(4),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(9),[A]),possibility,possibly) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(4),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(9),[A]),reveal) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(4),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(9),[A]),1,A) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',5,box(4),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(9),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',5,ref(8),[A])) :- guideline_entity(actual,A,'opioid-taper',countable), guideline_cardinality(actual,A,na,eq,1).
% S6: Every clinician should manage a taper-emergent-comorbidity and should provide a treatment.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec05-imp21',6,box(1),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',6,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',6,ref(2),[A]),'taper-emergent-comorbidity',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',6,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',6,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',6,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',6,ref(3),[A]),manage) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',6,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',6,ref(3),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',6,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',6,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',6,ref(2),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec05-imp21',6,box(2),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',6,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',6,ref(4),[A]),treatment,countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',6,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',6,ref(4),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',6,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',6,ref(5),[A]),provide) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',6,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',6,ref(5),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec05-imp21',6,box(2),[A]),'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',6,ref(5),[A]),2,'$guideline_id'(product,'cdc2022-opioid-rec05-imp21',6,ref(4),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
