% cdc2022-opioid-rec09-imp08.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
:- multifile(guideline_exclusion/1).
:- discontiguous(guideline_exclusion/1).
:- multifile(guideline_supersession/4).
:- discontiguous(guideline_supersession/4).
:- multifile(guideline_evaluation_date/1).
:- discontiguous(guideline_evaluation_date/1).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-rec09-imp08',ace_sha256('2c6729b4a77ed812206590c520b1ec332b004323472f935d6fa77ec56231b41b'),ulex(sha256(fba48e003101de64df33400ab2595fa7589360ac19f4c77ac3d17bd085f5b8c0)),vocabulary(sha256('335c132fd0e3d3163ba40c255e7db41eecc36492d8098263c505b17f44bbef5a'))).
% S1: If a clinician has a practice and reviews a state-PDMP-record for a patient then it is recommended that the clinician does not dismiss the patient from the practice on a PDMP-information-basis.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec09-imp08',1,box(1),[A,B,C,D,E,F]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,practice,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'state-PDMP-record',countable), guideline_cardinality(actual,D,na,eq,1), guideline_entity(actual,E,patient,countable), guideline_cardinality(actual,E,na,eq,1), guideline_event(actual,F,review), guideline_arg(actual,F,1,A), guideline_arg(actual,F,2,D), guideline_pp(actual,F,for,E), \+ guideline_exclusion('cdc-2022-opioid').
guideline_operator('$guideline_id'(context,'cdc2022-opioid-rec09-imp08',1,box(1),[A,B,C,D,E,F]),'$guideline_id'(context,'cdc2022-opioid-rec09-imp08',1,box(2),[A,B,C,D,E,F]),-) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,practice,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'state-PDMP-record',countable), guideline_cardinality(actual,D,na,eq,1), guideline_entity(actual,E,patient,countable), guideline_cardinality(actual,E,na,eq,1), guideline_event(actual,F,review), guideline_arg(actual,F,1,A), guideline_arg(actual,F,2,D), guideline_pp(actual,F,for,E).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec09-imp08',1,box(2),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec09-imp08',1,ref(7),[A,B,C,D,E,F]),'PDMP-information-basis',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,practice,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'state-PDMP-record',countable), guideline_cardinality(actual,D,na,eq,1), guideline_entity(actual,E,patient,countable), guideline_cardinality(actual,E,na,eq,1), guideline_event(actual,F,review), guideline_arg(actual,F,1,A), guideline_arg(actual,F,2,D), guideline_pp(actual,F,for,E).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec09-imp08',1,box(2),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec09-imp08',1,ref(7),[A,B,C,D,E,F]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,practice,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'state-PDMP-record',countable), guideline_cardinality(actual,D,na,eq,1), guideline_entity(actual,E,patient,countable), guideline_cardinality(actual,E,na,eq,1), guideline_event(actual,F,review), guideline_arg(actual,F,1,A), guideline_arg(actual,F,2,D), guideline_pp(actual,F,for,E).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec09-imp08',1,box(2),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec09-imp08',1,ref(8),[A,B,C,D,E,F]),dismiss) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,practice,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'state-PDMP-record',countable), guideline_cardinality(actual,D,na,eq,1), guideline_entity(actual,E,patient,countable), guideline_cardinality(actual,E,na,eq,1), guideline_event(actual,F,review), guideline_arg(actual,F,1,A), guideline_arg(actual,F,2,D), guideline_pp(actual,F,for,E).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec09-imp08',1,box(2),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec09-imp08',1,ref(8),[A,B,C,D,E,F]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,practice,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'state-PDMP-record',countable), guideline_cardinality(actual,D,na,eq,1), guideline_entity(actual,E,patient,countable), guideline_cardinality(actual,E,na,eq,1), guideline_event(actual,F,review), guideline_arg(actual,F,1,A), guideline_arg(actual,F,2,D), guideline_pp(actual,F,for,E).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec09-imp08',1,box(2),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec09-imp08',1,ref(8),[A,B,C,D,E,F]),2,E) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,practice,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'state-PDMP-record',countable), guideline_cardinality(actual,D,na,eq,1), guideline_entity(actual,E,patient,countable), guideline_cardinality(actual,E,na,eq,1), guideline_event(actual,F,review), guideline_arg(actual,F,1,A), guideline_arg(actual,F,2,D), guideline_pp(actual,F,for,E).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-rec09-imp08',1,box(2),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec09-imp08',1,ref(8),[A,B,C,D,E,F]),on,'$guideline_id'(product,'cdc2022-opioid-rec09-imp08',1,ref(7),[A,B,C,D,E,F])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,practice,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'state-PDMP-record',countable), guideline_cardinality(actual,D,na,eq,1), guideline_entity(actual,E,patient,countable), guideline_cardinality(actual,E,na,eq,1), guideline_event(actual,F,review), guideline_arg(actual,F,1,A), guideline_arg(actual,F,2,D), guideline_pp(actual,F,for,E).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-rec09-imp08',1,box(2),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec09-imp08',1,ref(8),[A,B,C,D,E,F]),from,B) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,practice,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'state-PDMP-record',countable), guideline_cardinality(actual,D,na,eq,1), guideline_entity(actual,E,patient,countable), guideline_cardinality(actual,E,na,eq,1), guideline_event(actual,F,review), guideline_arg(actual,F,1,A), guideline_arg(actual,F,2,D), guideline_pp(actual,F,for,E).
