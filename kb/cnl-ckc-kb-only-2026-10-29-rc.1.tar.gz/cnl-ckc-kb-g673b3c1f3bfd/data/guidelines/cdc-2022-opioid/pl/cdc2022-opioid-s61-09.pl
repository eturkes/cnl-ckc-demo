% cdc2022-opioid-s61-09.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
:- multifile(guideline_exclusion/1).
:- discontiguous(guideline_exclusion/1).
:- multifile(guideline_supersession/4).
:- discontiguous(guideline_supersession/4).
:- multifile(guideline_evaluation_date/1).
:- discontiguous(guideline_evaluation_date/1).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-s61-09',ace_sha256(c78c4ddb5f107567cabdfd3a86cd1ca4a56f22b3a0e0049860414a504d421d40),ulex(sha256(fba48e003101de64df33400ab2595fa7589360ac19f4c77ac3d17bd085f5b8c0)),vocabulary(sha256('335c132fd0e3d3163ba40c255e7db41eecc36492d8098263c505b17f44bbef5a'))).
% S1: Every payer may support a broader-nonpharmacologic-intervention-array.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s61-09',1,box(1),[A]),may) :- guideline_entity(actual,A,payer,countable), guideline_cardinality(actual,A,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s61-09',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s61-09',1,ref(2),[A]),'broader-nonpharmacologic-intervention-array',countable) :- guideline_entity(actual,A,payer,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s61-09',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s61-09',1,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,payer,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s61-09',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s61-09',1,ref(3),[A]),support) :- guideline_entity(actual,A,payer,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s61-09',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s61-09',1,ref(3),[A]),1,A) :- guideline_entity(actual,A,payer,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s61-09',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s61-09',1,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s61-09',1,ref(2),[A])) :- guideline_entity(actual,A,payer,countable), guideline_cardinality(actual,A,na,eq,1).
% S2: A broader-nonpharmacologic-intervention-example includes an exercise-example and includes a multidisciplinary-rehabilitation-example and includes a mind-body-intervention-example and includes a cognitive-behavioral-therapy-example and includes a known-effective-complementary-and-integrative-medicine-therapy-example.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(1),[]),'broader-nonpharmacologic-intervention-example',countable).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(1),[]),na,eq,1).
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(2),[]),'exercise-example',countable).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(2),[]),na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(3),[]),include).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(3),[]),1,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(1),[])).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(3),[]),2,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(2),[])).
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(4),[]),'multidisciplinary-rehabilitation-example',countable).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(4),[]),na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(5),[]),include).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(5),[]),1,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(1),[])).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(5),[]),2,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(4),[])).
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(6),[]),'mind-body-intervention-example',countable).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(6),[]),na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(7),[]),include).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(7),[]),1,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(1),[])).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(7),[]),2,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(6),[])).
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(8),[]),'cognitive-behavioral-therapy-example',countable).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(8),[]),na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(9),[]),include).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(9),[]),1,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(1),[])).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(9),[]),2,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(8),[])).
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(10),[]),'known-effective-complementary-and-integrative-medicine-therapy-example',countable).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(10),[]),na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(11),[]),include).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(11),[]),1,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(1),[])).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(11),[]),2,'$guideline_id'(product,'cdc2022-opioid-s61-09',2,ref(10),[])).
% S3: A known-effective-complementary-and-integrative-medicine-therapy-example includes an acupuncture-example and includes a spinal-manipulation-example.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',3,ref(1),[]),'known-effective-complementary-and-integrative-medicine-therapy-example',countable).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',3,ref(1),[]),na,eq,1).
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',3,ref(2),[]),'acupuncture-example',countable).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',3,ref(2),[]),na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',3,ref(3),[]),include).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',3,ref(3),[]),1,'$guideline_id'(product,'cdc2022-opioid-s61-09',3,ref(1),[])).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',3,ref(3),[]),2,'$guideline_id'(product,'cdc2022-opioid-s61-09',3,ref(2),[])).
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',3,ref(4),[]),'spinal-manipulation-example',countable).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',3,ref(4),[]),na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',3,ref(5),[]),include).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',3,ref(5),[]),1,'$guideline_id'(product,'cdc2022-opioid-s61-09',3,ref(1),[])).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s61-09',3,ref(5),[]),2,'$guideline_id'(product,'cdc2022-opioid-s61-09',3,ref(4),[])).
