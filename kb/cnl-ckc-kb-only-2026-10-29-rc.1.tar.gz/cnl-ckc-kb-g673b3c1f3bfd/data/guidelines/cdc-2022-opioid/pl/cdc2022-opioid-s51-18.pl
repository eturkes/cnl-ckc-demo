% cdc2022-opioid-s51-18.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
:- multifile(guideline_exclusion/1).
:- discontiguous(guideline_exclusion/1).
:- multifile(guideline_supersession/4).
:- discontiguous(guideline_supersession/4).
:- multifile(guideline_evaluation_date/1).
:- discontiguous(guideline_evaluation_date/1).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-s51-18',ace_sha256('2be63de7bed5c0de29cba765b81d7b6c07ccf1521f24860a7c7b960b4f7a6be4'),ulex(sha256(fba48e003101de64df33400ab2595fa7589360ac19f4c77ac3d17bd085f5b8c0)),vocabulary(sha256('335c132fd0e3d3163ba40c255e7db41eecc36492d8098263c505b17f44bbef5a'))).
% S1: Every PDMP-EHR-integration can outperform a separate-system-access in a clinician-burden-reduction.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s51-18',1,box(1),[A]),can) :- guideline_entity(actual,A,'PDMP-EHR-integration',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s51-18',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s51-18',1,ref(2),[A]),'separate-system-access',countable) :- guideline_entity(actual,A,'PDMP-EHR-integration',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s51-18',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s51-18',1,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'PDMP-EHR-integration',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s51-18',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s51-18',1,ref(3),[A]),'clinician-burden-reduction',countable) :- guideline_entity(actual,A,'PDMP-EHR-integration',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s51-18',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s51-18',1,ref(3),[A]),na,eq,1) :- guideline_entity(actual,A,'PDMP-EHR-integration',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s51-18',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s51-18',1,ref(4),[A]),outperform) :- guideline_entity(actual,A,'PDMP-EHR-integration',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s51-18',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s51-18',1,ref(4),[A]),1,A) :- guideline_entity(actual,A,'PDMP-EHR-integration',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s51-18',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s51-18',1,ref(4),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s51-18',1,ref(2),[A])) :- guideline_entity(actual,A,'PDMP-EHR-integration',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s51-18',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s51-18',1,ref(4),[A]),in,'$guideline_id'(product,'cdc2022-opioid-s51-18',1,ref(3),[A])) :- guideline_entity(actual,A,'PDMP-EHR-integration',countable), guideline_cardinality(actual,A,na,eq,1).
