% cdc2022-opioid-s29-20.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
:- multifile(guideline_exclusion/1).
:- discontiguous(guideline_exclusion/1).
:- multifile(guideline_supersession/4).
:- discontiguous(guideline_supersession/4).
:- multifile(guideline_evaluation_date/1).
:- discontiguous(guideline_evaluation_date/1).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-s29-20',ace_sha256('6bfa6946f200ad65f0c1d8fa31f2a00f76befe853614fd95f7ad5cba1f5e14d2'),ulex(sha256(fba48e003101de64df33400ab2595fa7589360ac19f4c77ac3d17bd085f5b8c0)),vocabulary(sha256('335c132fd0e3d3163ba40c255e7db41eecc36492d8098263c505b17f44bbef5a'))).
% S1: Every clinician should discuss a longitudinal-medication-use-reassessment with a patient.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s29-20',1,box(1),[A]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s29-20',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s29-20',1,ref(2),[A]),'longitudinal-medication-use-reassessment',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s29-20',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s29-20',1,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s29-20',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s29-20',1,ref(3),[A]),patient,countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s29-20',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s29-20',1,ref(3),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s29-20',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s29-20',1,ref(4),[A]),discuss) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s29-20',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s29-20',1,ref(4),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s29-20',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s29-20',1,ref(4),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s29-20',1,ref(2),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s29-20',1,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s29-20',1,ref(4),[A]),with,'$guideline_id'(product,'cdc2022-opioid-s29-20',1,ref(3),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
% S2: If a patient has a caregiver and a caregiver-involvement is appropriate for the patient then every clinician should discuss a longitudinal-medication-use-reassessment with the caregiver.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s29-20',2,box(1),[A,B,C,D,E,F,G]),should) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,caregiver,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'caregiver-involvement',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,F,be), guideline_arg(actual,F,1,D), guideline_arg(actual,F,2,E), guideline_property(actual,E,appropriate,pos), guideline_qualifier(actual,F,applicability,appropriate), guideline_pp(actual,F,for,A), guideline_entity(actual,G,clinician,countable), guideline_cardinality(actual,G,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s29-20',2,box(1),[A,B,C,D,E,F,G]),'$guideline_id'(product,'cdc2022-opioid-s29-20',2,ref(8),[A,B,C,D,E,F,G]),'longitudinal-medication-use-reassessment',countable) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,caregiver,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'caregiver-involvement',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,F,be), guideline_arg(actual,F,1,D), guideline_arg(actual,F,2,E), guideline_property(actual,E,appropriate,pos), guideline_qualifier(actual,F,applicability,appropriate), guideline_pp(actual,F,for,A), guideline_entity(actual,G,clinician,countable), guideline_cardinality(actual,G,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s29-20',2,box(1),[A,B,C,D,E,F,G]),'$guideline_id'(product,'cdc2022-opioid-s29-20',2,ref(8),[A,B,C,D,E,F,G]),na,eq,1) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,caregiver,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'caregiver-involvement',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,F,be), guideline_arg(actual,F,1,D), guideline_arg(actual,F,2,E), guideline_property(actual,E,appropriate,pos), guideline_qualifier(actual,F,applicability,appropriate), guideline_pp(actual,F,for,A), guideline_entity(actual,G,clinician,countable), guideline_cardinality(actual,G,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s29-20',2,box(1),[A,B,C,D,E,F,G]),'$guideline_id'(product,'cdc2022-opioid-s29-20',2,ref(9),[A,B,C,D,E,F,G]),discuss) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,caregiver,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'caregiver-involvement',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,F,be), guideline_arg(actual,F,1,D), guideline_arg(actual,F,2,E), guideline_property(actual,E,appropriate,pos), guideline_qualifier(actual,F,applicability,appropriate), guideline_pp(actual,F,for,A), guideline_entity(actual,G,clinician,countable), guideline_cardinality(actual,G,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s29-20',2,box(1),[A,B,C,D,E,F,G]),'$guideline_id'(product,'cdc2022-opioid-s29-20',2,ref(9),[A,B,C,D,E,F,G]),1,G) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,caregiver,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'caregiver-involvement',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,F,be), guideline_arg(actual,F,1,D), guideline_arg(actual,F,2,E), guideline_property(actual,E,appropriate,pos), guideline_qualifier(actual,F,applicability,appropriate), guideline_pp(actual,F,for,A), guideline_entity(actual,G,clinician,countable), guideline_cardinality(actual,G,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s29-20',2,box(1),[A,B,C,D,E,F,G]),'$guideline_id'(product,'cdc2022-opioid-s29-20',2,ref(9),[A,B,C,D,E,F,G]),2,'$guideline_id'(product,'cdc2022-opioid-s29-20',2,ref(8),[A,B,C,D,E,F,G])) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,caregiver,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'caregiver-involvement',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,F,be), guideline_arg(actual,F,1,D), guideline_arg(actual,F,2,E), guideline_property(actual,E,appropriate,pos), guideline_qualifier(actual,F,applicability,appropriate), guideline_pp(actual,F,for,A), guideline_entity(actual,G,clinician,countable), guideline_cardinality(actual,G,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s29-20',2,box(1),[A,B,C,D,E,F,G]),'$guideline_id'(product,'cdc2022-opioid-s29-20',2,ref(9),[A,B,C,D,E,F,G]),with,B) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,caregiver,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'caregiver-involvement',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,F,be), guideline_arg(actual,F,1,D), guideline_arg(actual,F,2,E), guideline_property(actual,E,appropriate,pos), guideline_qualifier(actual,F,applicability,appropriate), guideline_pp(actual,F,for,A), guideline_entity(actual,G,clinician,countable), guideline_cardinality(actual,G,na,eq,1).
