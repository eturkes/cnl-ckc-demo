% cdc2022-opioid-s37-17.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
:- multifile(guideline_exclusion/1).
:- discontiguous(guideline_exclusion/1).
:- multifile(guideline_supersession/4).
:- discontiguous(guideline_supersession/4).
:- multifile(guideline_evaluation_date/1).
:- discontiguous(guideline_evaluation_date/1).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-s37-17',ace_sha256('1bfb6dfe9ba936a1f9e5e01aa3aacc24bf60b30e094ff30edd1a93eb9240fd1a'),ulex(sha256(fba48e003101de64df33400ab2595fa7589360ac19f4c77ac3d17bd085f5b8c0)),vocabulary(sha256('335c132fd0e3d3163ba40c255e7db41eecc36492d8098263c505b17f44bbef5a'))).
% S1: If a patient-collaboration is possible for a patient and there is a clinician then it is recommended that the clinician collaborates with the patient on an opioid-taper-plan and uses a shared-decision-making with the patient for the opioid-taper-plan.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s37-17',1,box(1),[A,B,C,D,E]),should) :- guideline_entity(actual,A,'patient-collaboration',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,possible,pos), guideline_qualifier(actual,D,applicability,possible), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s37-17',1,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-s37-17',1,ref(6),[A,B,C,D,E]),'opioid-taper-plan',countable) :- guideline_entity(actual,A,'patient-collaboration',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,possible,pos), guideline_qualifier(actual,D,applicability,possible), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s37-17',1,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-s37-17',1,ref(6),[A,B,C,D,E]),na,eq,1) :- guideline_entity(actual,A,'patient-collaboration',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,possible,pos), guideline_qualifier(actual,D,applicability,possible), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s37-17',1,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-s37-17',1,ref(7),[A,B,C,D,E]),collaborate) :- guideline_entity(actual,A,'patient-collaboration',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,possible,pos), guideline_qualifier(actual,D,applicability,possible), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s37-17',1,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-s37-17',1,ref(7),[A,B,C,D,E]),1,E) :- guideline_entity(actual,A,'patient-collaboration',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,possible,pos), guideline_qualifier(actual,D,applicability,possible), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s37-17',1,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-s37-17',1,ref(7),[A,B,C,D,E]),on,'$guideline_id'(product,'cdc2022-opioid-s37-17',1,ref(6),[A,B,C,D,E])) :- guideline_entity(actual,A,'patient-collaboration',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,possible,pos), guideline_qualifier(actual,D,applicability,possible), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s37-17',1,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-s37-17',1,ref(7),[A,B,C,D,E]),with,B) :- guideline_entity(actual,A,'patient-collaboration',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,possible,pos), guideline_qualifier(actual,D,applicability,possible), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s37-17',1,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-s37-17',1,ref(8),[A,B,C,D,E]),'shared-decision-making',countable) :- guideline_entity(actual,A,'patient-collaboration',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,possible,pos), guideline_qualifier(actual,D,applicability,possible), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s37-17',1,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-s37-17',1,ref(8),[A,B,C,D,E]),na,eq,1) :- guideline_entity(actual,A,'patient-collaboration',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,possible,pos), guideline_qualifier(actual,D,applicability,possible), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s37-17',1,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-s37-17',1,ref(9),[A,B,C,D,E]),use) :- guideline_entity(actual,A,'patient-collaboration',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,possible,pos), guideline_qualifier(actual,D,applicability,possible), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s37-17',1,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-s37-17',1,ref(9),[A,B,C,D,E]),1,E) :- guideline_entity(actual,A,'patient-collaboration',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,possible,pos), guideline_qualifier(actual,D,applicability,possible), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s37-17',1,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-s37-17',1,ref(9),[A,B,C,D,E]),2,'$guideline_id'(product,'cdc2022-opioid-s37-17',1,ref(8),[A,B,C,D,E])) :- guideline_entity(actual,A,'patient-collaboration',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,possible,pos), guideline_qualifier(actual,D,applicability,possible), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s37-17',1,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-s37-17',1,ref(9),[A,B,C,D,E]),for,'$guideline_id'(product,'cdc2022-opioid-s37-17',1,ref(6),[A,B,C,D,E])) :- guideline_entity(actual,A,'patient-collaboration',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,possible,pos), guideline_qualifier(actual,D,applicability,possible), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s37-17',1,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-s37-17',1,ref(9),[A,B,C,D,E]),with,B) :- guideline_entity(actual,A,'patient-collaboration',countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,patient,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,possible,pos), guideline_qualifier(actual,D,applicability,possible), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
