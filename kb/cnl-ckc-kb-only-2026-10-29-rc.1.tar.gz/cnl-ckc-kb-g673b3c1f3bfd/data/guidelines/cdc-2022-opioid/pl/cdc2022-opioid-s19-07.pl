% cdc2022-opioid-s19-07.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
:- multifile(guideline_exclusion/1).
:- discontiguous(guideline_exclusion/1).
:- multifile(guideline_supersession/4).
:- discontiguous(guideline_supersession/4).
:- multifile(guideline_evaluation_date/1).
:- discontiguous(guideline_evaluation_date/1).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-s19-07',ace_sha256('6fc0fbc66e7f3ab3e77e5adfe954124e25044bf73c19c4f447d8a47d9ac8de9c'),ulex(sha256(fba48e003101de64df33400ab2595fa7589360ac19f4c77ac3d17bd085f5b8c0)),vocabulary(sha256('335c132fd0e3d3163ba40c255e7db41eecc36492d8098263c505b17f44bbef5a'))).
% S1: Every clinician is a pain-equity-duty-holder.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',1,ref(2),[A]),'pain-equity-duty-holder',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',1,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',1,ref(3),[A]),be) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',1,ref(3),[A]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',1,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s19-07',1,ref(2),[A])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1).
% S2: Every clinical-practice-organization is a pain-equity-duty-holder.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',2,ref(2),[A]),'pain-equity-duty-holder',countable) :- guideline_entity(actual,A,'clinical-practice-organization',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',2,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'clinical-practice-organization',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',2,ref(3),[A]),be) :- guideline_entity(actual,A,'clinical-practice-organization',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',2,ref(3),[A]),1,A) :- guideline_entity(actual,A,'clinical-practice-organization',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',2,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s19-07',2,ref(2),[A])) :- guideline_entity(actual,A,'clinical-practice-organization',countable), guideline_cardinality(actual,A,na,eq,1).
% S3: Every health-system is a pain-equity-duty-holder.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',3,ref(2),[A]),'pain-equity-duty-holder',countable) :- guideline_entity(actual,A,'health-system',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',3,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'health-system',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',3,ref(3),[A]),be) :- guideline_entity(actual,A,'health-system',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',3,ref(3),[A]),1,A) :- guideline_entity(actual,A,'health-system',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',3,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s19-07',3,ref(2),[A])) :- guideline_entity(actual,A,'health-system',countable), guideline_cardinality(actual,A,na,eq,1).
% S4: Every payer is a pain-equity-duty-holder.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',4,ref(2),[A]),'pain-equity-duty-holder',countable) :- guideline_entity(actual,A,payer,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',4,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,payer,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',4,ref(3),[A]),be) :- guideline_entity(actual,A,payer,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',4,ref(3),[A]),1,A) :- guideline_entity(actual,A,payer,countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s19-07',4,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s19-07',4,ref(2),[A])) :- guideline_entity(actual,A,payer,countable), guideline_cardinality(actual,A,na,eq,1).
% S5: Every pain-equity-duty-holder should vigilantly monitor a health-inequity.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s19-07',5,box(1),[A]),should) :- guideline_entity(actual,A,'pain-equity-duty-holder',countable), guideline_cardinality(actual,A,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s19-07',5,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s19-07',5,ref(2),[A]),'health-inequity',countable) :- guideline_entity(actual,A,'pain-equity-duty-holder',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s19-07',5,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s19-07',5,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'pain-equity-duty-holder',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_qualifier('$guideline_id'(context,'cdc2022-opioid-s19-07',5,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s19-07',5,ref(3),[A]),manner,vigilantly) :- guideline_entity(actual,A,'pain-equity-duty-holder',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s19-07',5,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s19-07',5,ref(3),[A]),monitor) :- guideline_entity(actual,A,'pain-equity-duty-holder',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s19-07',5,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s19-07',5,ref(3),[A]),1,A) :- guideline_entity(actual,A,'pain-equity-duty-holder',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s19-07',5,box(1),[A]),'$guideline_id'(product,'cdc2022-opioid-s19-07',5,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s19-07',5,ref(2),[A])) :- guideline_entity(actual,A,'pain-equity-duty-holder',countable), guideline_cardinality(actual,A,na,eq,1).
% S6: If there is a patient then every pain-equity-duty-holder should communicate culturally-appropriately with the patient.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s19-07',6,box(1),[A,B]),should) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_event('$guideline_id'(context,'cdc2022-opioid-s19-07',6,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',6,ref(3),[A,B]),communicate) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s19-07',6,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',6,ref(3),[A,B]),1,B) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s19-07',6,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',6,ref(3),[A,B]),with,A) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
guideline_qualifier('$guideline_id'(context,'cdc2022-opioid-s19-07',6,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',6,ref(3),[A,B]),manner,'culturally-appropriately') :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
% S7: If there is a patient then every pain-equity-duty-holder should communicate linguistically-appropriately with the patient.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s19-07',7,box(1),[A,B]),should) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_event('$guideline_id'(context,'cdc2022-opioid-s19-07',7,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',7,ref(3),[A,B]),communicate) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s19-07',7,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',7,ref(3),[A,B]),1,B) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s19-07',7,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',7,ref(3),[A,B]),with,A) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
guideline_qualifier('$guideline_id'(context,'cdc2022-opioid-s19-07',7,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',7,ref(3),[A,B]),manner,'linguistically-appropriately') :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
% S8: If a patient has a disability then every pain-equity-duty-holder should provide a disability-accessible-communication for the patient.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s19-07',8,box(1),[A,B,C,D]),should) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,disability,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'pain-equity-duty-holder',countable), guideline_cardinality(actual,D,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s19-07',8,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s19-07',8,ref(5),[A,B,C,D]),'disability-accessible-communication',countable) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,disability,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'pain-equity-duty-holder',countable), guideline_cardinality(actual,D,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s19-07',8,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s19-07',8,ref(5),[A,B,C,D]),na,eq,1) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,disability,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'pain-equity-duty-holder',countable), guideline_cardinality(actual,D,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s19-07',8,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s19-07',8,ref(6),[A,B,C,D]),provide) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,disability,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'pain-equity-duty-holder',countable), guideline_cardinality(actual,D,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s19-07',8,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s19-07',8,ref(6),[A,B,C,D]),1,D) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,disability,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'pain-equity-duty-holder',countable), guideline_cardinality(actual,D,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s19-07',8,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s19-07',8,ref(6),[A,B,C,D]),2,'$guideline_id'(product,'cdc2022-opioid-s19-07',8,ref(5),[A,B,C,D])) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,disability,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'pain-equity-duty-holder',countable), guideline_cardinality(actual,D,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s19-07',8,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-s19-07',8,ref(6),[A,B,C,D]),for,A) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,disability,countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'pain-equity-duty-holder',countable), guideline_cardinality(actual,D,na,eq,1).
% S9: If there is a patient then every pain-equity-duty-holder should ensure an appropriate-affordable-diversified-coordinated-effective-nonpharmacologic-pain-management-access for the patient.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s19-07',9,box(1),[A,B]),should) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s19-07',9,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',9,ref(3),[A,B]),'appropriate-affordable-diversified-coordinated-effective-nonpharmacologic-pain-management-access',countable) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s19-07',9,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',9,ref(3),[A,B]),na,eq,1) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s19-07',9,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',9,ref(4),[A,B]),ensure) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s19-07',9,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',9,ref(4),[A,B]),1,B) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s19-07',9,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',9,ref(4),[A,B]),2,'$guideline_id'(product,'cdc2022-opioid-s19-07',9,ref(3),[A,B])) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s19-07',9,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',9,ref(4),[A,B]),for,A) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
% S10: If there is a patient then every pain-equity-duty-holder should ensure an appropriate-affordable-diversified-coordinated-effective-pharmacologic-pain-management-access for the patient.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s19-07',10,box(1),[A,B]),should) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s19-07',10,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',10,ref(3),[A,B]),'appropriate-affordable-diversified-coordinated-effective-pharmacologic-pain-management-access',countable) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s19-07',10,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',10,ref(3),[A,B]),na,eq,1) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s19-07',10,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',10,ref(4),[A,B]),ensure) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s19-07',10,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',10,ref(4),[A,B]),1,B) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s19-07',10,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',10,ref(4),[A,B]),2,'$guideline_id'(product,'cdc2022-opioid-s19-07',10,ref(3),[A,B])) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s19-07',10,box(1),[A,B]),'$guideline_id'(product,'cdc2022-opioid-s19-07',10,ref(4),[A,B]),for,A) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'pain-equity-duty-holder',countable), guideline_cardinality(actual,B,na,eq,1).
