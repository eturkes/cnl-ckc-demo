% cdc2022-opioid-rec06-imp13.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
:- multifile(guideline_exclusion/1).
:- discontiguous(guideline_exclusion/1).
:- multifile(guideline_supersession/4).
:- discontiguous(guideline_supersession/4).
:- multifile(guideline_evaluation_date/1).
:- discontiguous(guideline_evaluation_date/1).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-rec06-imp13',ace_sha256(fbc9f1df5712b14d7b002e3ec97a097e90d6d3f2c8d0dd10c4f89e86a5100e48),ulex(sha256(fba48e003101de64df33400ab2595fa7589360ac19f4c77ac3d17bd085f5b8c0)),vocabulary(sha256('335c132fd0e3d3163ba40c255e7db41eecc36492d8098263c505b17f44bbef5a'))).
% S1: If a patient has a prolonged-around-the-clock-opioid-use for an acute-pain during a few-day-period then every clinician should prescribe a brief-withdrawal-minimizing-taper for the patient during an opioid-discontinuation.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec06-imp13',1,box(1),[A,B,C,D,E,F]),should) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'prolonged-around-the-clock-opioid-use',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,'acute-pain',countable), guideline_cardinality(actual,C,na,eq,1), guideline_entity(actual,D,'few-day-period',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,have), guideline_arg(actual,E,1,A), guideline_arg(actual,E,2,B), guideline_pp(actual,E,during,D), guideline_pp(actual,E,for,C), guideline_entity(actual,F,clinician,countable), guideline_cardinality(actual,F,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec06-imp13',1,box(1),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec06-imp13',1,ref(7),[A,B,C,D,E,F]),'brief-withdrawal-minimizing-taper',countable) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'prolonged-around-the-clock-opioid-use',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,'acute-pain',countable), guideline_cardinality(actual,C,na,eq,1), guideline_entity(actual,D,'few-day-period',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,have), guideline_arg(actual,E,1,A), guideline_arg(actual,E,2,B), guideline_pp(actual,E,during,D), guideline_pp(actual,E,for,C), guideline_entity(actual,F,clinician,countable), guideline_cardinality(actual,F,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec06-imp13',1,box(1),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec06-imp13',1,ref(7),[A,B,C,D,E,F]),na,eq,1) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'prolonged-around-the-clock-opioid-use',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,'acute-pain',countable), guideline_cardinality(actual,C,na,eq,1), guideline_entity(actual,D,'few-day-period',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,have), guideline_arg(actual,E,1,A), guideline_arg(actual,E,2,B), guideline_pp(actual,E,during,D), guideline_pp(actual,E,for,C), guideline_entity(actual,F,clinician,countable), guideline_cardinality(actual,F,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec06-imp13',1,box(1),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec06-imp13',1,ref(8),[A,B,C,D,E,F]),'opioid-discontinuation',countable) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'prolonged-around-the-clock-opioid-use',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,'acute-pain',countable), guideline_cardinality(actual,C,na,eq,1), guideline_entity(actual,D,'few-day-period',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,have), guideline_arg(actual,E,1,A), guideline_arg(actual,E,2,B), guideline_pp(actual,E,during,D), guideline_pp(actual,E,for,C), guideline_entity(actual,F,clinician,countable), guideline_cardinality(actual,F,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec06-imp13',1,box(1),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec06-imp13',1,ref(8),[A,B,C,D,E,F]),na,eq,1) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'prolonged-around-the-clock-opioid-use',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,'acute-pain',countable), guideline_cardinality(actual,C,na,eq,1), guideline_entity(actual,D,'few-day-period',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,have), guideline_arg(actual,E,1,A), guideline_arg(actual,E,2,B), guideline_pp(actual,E,during,D), guideline_pp(actual,E,for,C), guideline_entity(actual,F,clinician,countable), guideline_cardinality(actual,F,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec06-imp13',1,box(1),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec06-imp13',1,ref(9),[A,B,C,D,E,F]),prescribe) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'prolonged-around-the-clock-opioid-use',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,'acute-pain',countable), guideline_cardinality(actual,C,na,eq,1), guideline_entity(actual,D,'few-day-period',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,have), guideline_arg(actual,E,1,A), guideline_arg(actual,E,2,B), guideline_pp(actual,E,during,D), guideline_pp(actual,E,for,C), guideline_entity(actual,F,clinician,countable), guideline_cardinality(actual,F,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec06-imp13',1,box(1),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec06-imp13',1,ref(9),[A,B,C,D,E,F]),1,F) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'prolonged-around-the-clock-opioid-use',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,'acute-pain',countable), guideline_cardinality(actual,C,na,eq,1), guideline_entity(actual,D,'few-day-period',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,have), guideline_arg(actual,E,1,A), guideline_arg(actual,E,2,B), guideline_pp(actual,E,during,D), guideline_pp(actual,E,for,C), guideline_entity(actual,F,clinician,countable), guideline_cardinality(actual,F,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec06-imp13',1,box(1),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec06-imp13',1,ref(9),[A,B,C,D,E,F]),2,'$guideline_id'(product,'cdc2022-opioid-rec06-imp13',1,ref(7),[A,B,C,D,E,F])) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'prolonged-around-the-clock-opioid-use',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,'acute-pain',countable), guideline_cardinality(actual,C,na,eq,1), guideline_entity(actual,D,'few-day-period',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,have), guideline_arg(actual,E,1,A), guideline_arg(actual,E,2,B), guideline_pp(actual,E,during,D), guideline_pp(actual,E,for,C), guideline_entity(actual,F,clinician,countable), guideline_cardinality(actual,F,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-rec06-imp13',1,box(1),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec06-imp13',1,ref(9),[A,B,C,D,E,F]),during,'$guideline_id'(product,'cdc2022-opioid-rec06-imp13',1,ref(8),[A,B,C,D,E,F])) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'prolonged-around-the-clock-opioid-use',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,'acute-pain',countable), guideline_cardinality(actual,C,na,eq,1), guideline_entity(actual,D,'few-day-period',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,have), guideline_arg(actual,E,1,A), guideline_arg(actual,E,2,B), guideline_pp(actual,E,during,D), guideline_pp(actual,E,for,C), guideline_entity(actual,F,clinician,countable), guideline_cardinality(actual,F,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-rec06-imp13',1,box(1),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec06-imp13',1,ref(9),[A,B,C,D,E,F]),for,A) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'prolonged-around-the-clock-opioid-use',countable), guideline_cardinality(actual,B,na,eq,1), guideline_entity(actual,C,'acute-pain',countable), guideline_cardinality(actual,C,na,eq,1), guideline_entity(actual,D,'few-day-period',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,have), guideline_arg(actual,E,1,A), guideline_arg(actual,E,2,B), guideline_pp(actual,E,during,D), guideline_pp(actual,E,for,C), guideline_entity(actual,F,clinician,countable), guideline_cardinality(actual,F,na,eq,1).
