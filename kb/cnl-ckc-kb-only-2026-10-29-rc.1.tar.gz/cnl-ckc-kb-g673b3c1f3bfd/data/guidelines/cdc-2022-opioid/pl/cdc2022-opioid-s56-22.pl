% cdc2022-opioid-s56-22.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
:- multifile(guideline_exclusion/1).
:- discontiguous(guideline_exclusion/1).
:- multifile(guideline_supersession/4).
:- discontiguous(guideline_supersession/4).
:- multifile(guideline_evaluation_date/1).
:- discontiguous(guideline_evaluation_date/1).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-s56-22',ace_sha256('810264c5f7d0f181f9dc01e10f47f348de8b814fdb9f1399488101b7cbdb7f3d'),ulex(sha256(fba48e003101de64df33400ab2595fa7589360ac19f4c77ac3d17bd085f5b8c0)),vocabulary(sha256('335c132fd0e3d3163ba40c255e7db41eecc36492d8098263c505b17f44bbef5a'))).
% S1: If a person has an opioid-use-disorder then a stigma can reduce a treatment-seeking-willingness for the person.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s56-22',1,ref(4),[A,B,C]),stigma,countable) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s56-22',1,ref(4),[A,B,C]),na,eq,1) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s56-22',1,box(1),[A,B,C]),can) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s56-22',1,box(1),[A,B,C]),'$guideline_id'(product,'cdc2022-opioid-s56-22',1,ref(5),[A,B,C]),'treatment-seeking-willingness',countable) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s56-22',1,box(1),[A,B,C]),'$guideline_id'(product,'cdc2022-opioid-s56-22',1,ref(5),[A,B,C]),na,eq,1) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s56-22',1,box(1),[A,B,C]),'$guideline_id'(product,'cdc2022-opioid-s56-22',1,ref(6),[A,B,C]),reduce) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s56-22',1,box(1),[A,B,C]),'$guideline_id'(product,'cdc2022-opioid-s56-22',1,ref(6),[A,B,C]),1,'$guideline_id'(product,'cdc2022-opioid-s56-22',1,ref(4),[A,B,C])) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s56-22',1,box(1),[A,B,C]),'$guideline_id'(product,'cdc2022-opioid-s56-22',1,ref(6),[A,B,C]),2,'$guideline_id'(product,'cdc2022-opioid-s56-22',1,ref(5),[A,B,C])) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s56-22',1,box(1),[A,B,C]),'$guideline_id'(product,'cdc2022-opioid-s56-22',1,ref(6),[A,B,C]),for,A) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B).
% S2: Every opioid-use-disorder is a chronic-treatable-disease.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s56-22',2,ref(2),[A]),'chronic-treatable-disease',countable) :- guideline_entity(actual,A,'opioid-use-disorder',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s56-22',2,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'opioid-use-disorder',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s56-22',2,ref(3),[A]),be) :- guideline_entity(actual,A,'opioid-use-disorder',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s56-22',2,ref(3),[A]),1,A) :- guideline_entity(actual,A,'opioid-use-disorder',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s56-22',2,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s56-22',2,ref(2),[A])) :- guideline_entity(actual,A,'opioid-use-disorder',countable), guideline_cardinality(actual,A,na,eq,1).
% S3: If a person has an opioid-use-disorder then the person can recover from the opioid-use-disorder and can lead a healthy-life.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s56-22',3,box(1),[A,B,C]),can) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s56-22',3,box(1),[A,B,C]),'$guideline_id'(product,'cdc2022-opioid-s56-22',3,ref(4),[A,B,C]),recover) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s56-22',3,box(1),[A,B,C]),'$guideline_id'(product,'cdc2022-opioid-s56-22',3,ref(4),[A,B,C]),1,A) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-s56-22',3,box(1),[A,B,C]),'$guideline_id'(product,'cdc2022-opioid-s56-22',3,ref(4),[A,B,C]),from,B) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-s56-22',3,box(2),[A,B,C]),can) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-s56-22',3,box(2),[A,B,C]),'$guideline_id'(product,'cdc2022-opioid-s56-22',3,ref(5),[A,B,C]),'healthy-life',countable) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-s56-22',3,box(2),[A,B,C]),'$guideline_id'(product,'cdc2022-opioid-s56-22',3,ref(5),[A,B,C]),na,eq,1) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B).
guideline_event('$guideline_id'(context,'cdc2022-opioid-s56-22',3,box(2),[A,B,C]),'$guideline_id'(product,'cdc2022-opioid-s56-22',3,ref(6),[A,B,C]),lead) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s56-22',3,box(2),[A,B,C]),'$guideline_id'(product,'cdc2022-opioid-s56-22',3,ref(6),[A,B,C]),1,A) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-s56-22',3,box(2),[A,B,C]),'$guideline_id'(product,'cdc2022-opioid-s56-22',3,ref(6),[A,B,C]),2,'$guideline_id'(product,'cdc2022-opioid-s56-22',3,ref(5),[A,B,C])) :- guideline_entity(actual,A,person,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'opioid-use-disorder',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,have), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B).
