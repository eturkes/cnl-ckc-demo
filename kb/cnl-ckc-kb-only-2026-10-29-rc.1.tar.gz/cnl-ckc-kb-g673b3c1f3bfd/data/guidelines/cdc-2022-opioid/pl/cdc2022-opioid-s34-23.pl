% cdc2022-opioid-s34-23.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
:- multifile(guideline_exclusion/1).
:- discontiguous(guideline_exclusion/1).
:- multifile(guideline_supersession/4).
:- discontiguous(guideline_supersession/4).
:- multifile(guideline_evaluation_date/1).
:- discontiguous(guideline_evaluation_date/1).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-s34-23',ace_sha256(d9cc89fbebb02c9aa096d47c467ae87a7fe2f043fe982c50e25f5fe4fd42e9b6),ulex(sha256(fba48e003101de64df33400ab2595fa7589360ac19f4c77ac3d17bd085f5b8c0)),vocabulary(sha256('335c132fd0e3d3163ba40c255e7db41eecc36492d8098263c505b17f44bbef5a'))).
% S1: Every rapid-dosage-increase increases a patient-sedation-risk.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s34-23',1,ref(2),[A]),'patient-sedation-risk',countable) :- guideline_entity(actual,A,'rapid-dosage-increase',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s34-23',1,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'rapid-dosage-increase',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s34-23',1,ref(3),[A]),increase) :- guideline_entity(actual,A,'rapid-dosage-increase',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s34-23',1,ref(3),[A]),1,A) :- guideline_entity(actual,A,'rapid-dosage-increase',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s34-23',1,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s34-23',1,ref(2),[A])) :- guideline_entity(actual,A,'rapid-dosage-increase',countable), guideline_cardinality(actual,A,na,eq,1).
% S2: Every rapid-dosage-increase increases a patient-respiratory-depression-risk.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s34-23',2,ref(2),[A]),'patient-respiratory-depression-risk',countable) :- guideline_entity(actual,A,'rapid-dosage-increase',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s34-23',2,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'rapid-dosage-increase',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s34-23',2,ref(3),[A]),increase) :- guideline_entity(actual,A,'rapid-dosage-increase',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s34-23',2,ref(3),[A]),1,A) :- guideline_entity(actual,A,'rapid-dosage-increase',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s34-23',2,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s34-23',2,ref(2),[A])) :- guideline_entity(actual,A,'rapid-dosage-increase',countable), guideline_cardinality(actual,A,na,eq,1).
% S3: Every rapid-dosage-increase increases a patient-overdose-risk.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s34-23',3,ref(2),[A]),'patient-overdose-risk',countable) :- guideline_entity(actual,A,'rapid-dosage-increase',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s34-23',3,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'rapid-dosage-increase',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s34-23',3,ref(3),[A]),increase) :- guideline_entity(actual,A,'rapid-dosage-increase',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s34-23',3,ref(3),[A]),1,A) :- guideline_entity(actual,A,'rapid-dosage-increase',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s34-23',3,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s34-23',3,ref(2),[A])) :- guideline_entity(actual,A,'rapid-dosage-increase',countable), guideline_cardinality(actual,A,na,eq,1).
% S4: Every specific-titration-interval-evidence is limited.
guideline_property(actual,'$guideline_id'(product,'cdc2022-opioid-s34-23',4,ref(2),[A]),limited,pos) :- guideline_entity(actual,A,'specific-titration-interval-evidence',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s34-23',4,ref(3),[A]),be) :- guideline_entity(actual,A,'specific-titration-interval-evidence',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s34-23',4,ref(3),[A]),1,A) :- guideline_entity(actual,A,'specific-titration-interval-evidence',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s34-23',4,ref(3),[A]),2,'$guideline_id'(product,'cdc2022-opioid-s34-23',4,ref(2),[A])) :- guideline_entity(actual,A,'specific-titration-interval-evidence',countable), guideline_cardinality(actual,A,na,eq,1).
