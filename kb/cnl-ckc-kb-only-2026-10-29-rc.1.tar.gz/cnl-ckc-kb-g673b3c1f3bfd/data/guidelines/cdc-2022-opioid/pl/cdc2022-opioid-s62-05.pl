% cdc2022-opioid-s62-05.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
:- multifile(guideline_exclusion/1).
:- discontiguous(guideline_exclusion/1).
:- multifile(guideline_supersession/4).
:- discontiguous(guideline_supersession/4).
:- multifile(guideline_evaluation_date/1).
:- discontiguous(guideline_evaluation_date/1).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-s62-05',ace_sha256(f725fa0c488fe704d0dc8058ea4a3256d9b377b13117ca84cb6f614514cfc4b5),ulex(sha256(fba48e003101de64df33400ab2595fa7589360ac19f4c77ac3d17bd085f5b8c0)),vocabulary(sha256('335c132fd0e3d3163ba40c255e7db41eecc36492d8098263c505b17f44bbef5a'))).
% S1: Every health-inequity-response begins with an inequity-awareness-raising-and-acknowledgment.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',1,ref(2),[A]),'inequity-awareness-raising-and-acknowledgment',countable) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',1,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',1,ref(3),[A]),begin) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',1,ref(3),[A]),1,A) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_pp(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',1,ref(3),[A]),with,'$guideline_id'(product,'cdc2022-opioid-s62-05',1,ref(2),[A])) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
% S2: Every health-inequity-response begins with a patient-clinician-communication-strengthening.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',2,ref(2),[A]),'patient-clinician-communication-strengthening',countable) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',2,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',2,ref(3),[A]),begin) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',2,ref(3),[A]),1,A) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_pp(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',2,ref(3),[A]),with,'$guideline_id'(product,'cdc2022-opioid-s62-05',2,ref(2),[A])) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
% S3: Every health-inequity-response begins with a community-health-worker-leveraging.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',3,ref(2),[A]),'community-health-worker-leveraging',countable) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',3,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',3,ref(3),[A]),begin) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',3,ref(3),[A]),1,A) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_pp(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',3,ref(3),[A]),with,'$guideline_id'(product,'cdc2022-opioid-s62-05',3,ref(2),[A])) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
% S4: Every health-inequity-response begins with a multidisciplinary-care-team-implementation.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',4,ref(2),[A]),'multidisciplinary-care-team-implementation',countable) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',4,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',4,ref(3),[A]),begin) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',4,ref(3),[A]),1,A) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_pp(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',4,ref(3),[A]),with,'$guideline_id'(product,'cdc2022-opioid-s62-05',4,ref(2),[A])) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
% S5: Every health-inequity-response begins with a performance-measure-tracking-and-monitoring.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',5,ref(2),[A]),'performance-measure-tracking-and-monitoring',countable) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',5,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',5,ref(3),[A]),begin) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',5,ref(3),[A]),1,A) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_pp(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',5,ref(3),[A]),with,'$guideline_id'(product,'cdc2022-opioid-s62-05',5,ref(2),[A])) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
% S6: Every health-inequity-response begins with an all-person-guideline-concordant-care-quality-improvement-integration.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',6,ref(2),[A]),'all-person-guideline-concordant-care-quality-improvement-integration',countable) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',6,ref(2),[A]),na,eq,1) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',6,ref(3),[A]),begin) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',6,ref(3),[A]),1,A) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
guideline_pp(actual,'$guideline_id'(product,'cdc2022-opioid-s62-05',6,ref(3),[A]),with,'$guideline_id'(product,'cdc2022-opioid-s62-05',6,ref(2),[A])) :- guideline_entity(actual,A,'health-inequity-response',countable), guideline_cardinality(actual,A,na,eq,1).
