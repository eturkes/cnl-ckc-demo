% cdc2022-opioid-rec08-imp19.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
:- multifile(guideline_exclusion/1).
:- discontiguous(guideline_exclusion/1).
:- multifile(guideline_supersession/4).
:- discontiguous(guideline_supersession/4).
:- multifile(guideline_evaluation_date/1).
:- discontiguous(guideline_evaluation_date/1).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-rec08-imp19',ace_sha256('369527e4ff322ecd8caf569efd3b2c70415c7b4ea27daeb3e8b7102ccb00e916'),ulex(sha256(fba48e003101de64df33400ab2595fa7589360ac19f4c77ac3d17bd085f5b8c0)),vocabulary(sha256('335c132fd0e3d3163ba40c255e7db41eecc36492d8098263c505b17f44bbef5a'))).
% S1: If a patient experiences a nonfatal-opioid-overdose then every clinician should evaluate an opioid-use-disorder for the patient.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec08-imp19',1,box(1),[A,B,C,D]),should) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'nonfatal-opioid-overdose',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,experience), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,clinician,countable), guideline_cardinality(actual,D,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec08-imp19',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec08-imp19',1,ref(5),[A,B,C,D]),'opioid-use-disorder',countable) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'nonfatal-opioid-overdose',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,experience), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,clinician,countable), guideline_cardinality(actual,D,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec08-imp19',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec08-imp19',1,ref(5),[A,B,C,D]),na,eq,1) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'nonfatal-opioid-overdose',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,experience), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,clinician,countable), guideline_cardinality(actual,D,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec08-imp19',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec08-imp19',1,ref(6),[A,B,C,D]),evaluate) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'nonfatal-opioid-overdose',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,experience), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,clinician,countable), guideline_cardinality(actual,D,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec08-imp19',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec08-imp19',1,ref(6),[A,B,C,D]),1,D) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'nonfatal-opioid-overdose',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,experience), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,clinician,countable), guideline_cardinality(actual,D,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec08-imp19',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec08-imp19',1,ref(6),[A,B,C,D]),2,'$guideline_id'(product,'cdc2022-opioid-rec08-imp19',1,ref(5),[A,B,C,D])) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'nonfatal-opioid-overdose',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,experience), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,clinician,countable), guideline_cardinality(actual,D,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-rec08-imp19',1,box(1),[A,B,C,D]),'$guideline_id'(product,'cdc2022-opioid-rec08-imp19',1,ref(6),[A,B,C,D]),for,A) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'nonfatal-opioid-overdose',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,experience), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,clinician,countable), guideline_cardinality(actual,D,na,eq,1).
% S2: If a patient experiences a nonfatal-opioid-overdose and the patient has an opioid-use-disorder-treatment-need then every clinician should ensure an opioid-use-disorder-treatment for the patient.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec08-imp19',2,box(1),[A,B,C,D,E,F]),should) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'nonfatal-opioid-overdose',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,experience), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'opioid-use-disorder-treatment-need',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,have), guideline_arg(actual,E,1,A), guideline_arg(actual,E,2,D), guideline_entity(actual,F,clinician,countable), guideline_cardinality(actual,F,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec08-imp19',2,box(1),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec08-imp19',2,ref(7),[A,B,C,D,E,F]),'opioid-use-disorder-treatment',countable) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'nonfatal-opioid-overdose',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,experience), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'opioid-use-disorder-treatment-need',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,have), guideline_arg(actual,E,1,A), guideline_arg(actual,E,2,D), guideline_entity(actual,F,clinician,countable), guideline_cardinality(actual,F,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec08-imp19',2,box(1),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec08-imp19',2,ref(7),[A,B,C,D,E,F]),na,eq,1) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'nonfatal-opioid-overdose',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,experience), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'opioid-use-disorder-treatment-need',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,have), guideline_arg(actual,E,1,A), guideline_arg(actual,E,2,D), guideline_entity(actual,F,clinician,countable), guideline_cardinality(actual,F,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec08-imp19',2,box(1),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec08-imp19',2,ref(8),[A,B,C,D,E,F]),ensure) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'nonfatal-opioid-overdose',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,experience), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'opioid-use-disorder-treatment-need',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,have), guideline_arg(actual,E,1,A), guideline_arg(actual,E,2,D), guideline_entity(actual,F,clinician,countable), guideline_cardinality(actual,F,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec08-imp19',2,box(1),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec08-imp19',2,ref(8),[A,B,C,D,E,F]),1,F) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'nonfatal-opioid-overdose',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,experience), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'opioid-use-disorder-treatment-need',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,have), guideline_arg(actual,E,1,A), guideline_arg(actual,E,2,D), guideline_entity(actual,F,clinician,countable), guideline_cardinality(actual,F,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec08-imp19',2,box(1),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec08-imp19',2,ref(8),[A,B,C,D,E,F]),2,'$guideline_id'(product,'cdc2022-opioid-rec08-imp19',2,ref(7),[A,B,C,D,E,F])) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'nonfatal-opioid-overdose',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,experience), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'opioid-use-disorder-treatment-need',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,have), guideline_arg(actual,E,1,A), guideline_arg(actual,E,2,D), guideline_entity(actual,F,clinician,countable), guideline_cardinality(actual,F,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-rec08-imp19',2,box(1),[A,B,C,D,E,F]),'$guideline_id'(product,'cdc2022-opioid-rec08-imp19',2,ref(8),[A,B,C,D,E,F]),for,A) :- guideline_entity(actual,A,patient,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'nonfatal-opioid-overdose',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,experience), guideline_arg(actual,C,1,A), guideline_arg(actual,C,2,B), guideline_entity(actual,D,'opioid-use-disorder-treatment-need',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,have), guideline_arg(actual,E,1,A), guideline_arg(actual,E,2,D), guideline_entity(actual,F,clinician,countable), guideline_cardinality(actual,F,na,eq,1).
