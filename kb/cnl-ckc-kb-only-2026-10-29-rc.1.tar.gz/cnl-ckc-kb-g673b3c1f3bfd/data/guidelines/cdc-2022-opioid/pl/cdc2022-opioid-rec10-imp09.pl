% cdc2022-opioid-rec10-imp09.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
:- multifile(guideline_exclusion/1).
:- discontiguous(guideline_exclusion/1).
:- multifile(guideline_supersession/4).
:- discontiguous(guideline_supersession/4).
:- multifile(guideline_evaluation_date/1).
:- discontiguous(guideline_evaluation_date/1).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-rec10-imp09',ace_sha256('15439a0398bdff7f23eab972255d24ea3e7301db823e44bf5c368ee187135d10'),ulex(sha256(fba48e003101de64df33400ab2595fa7589360ac19f4c77ac3d17bd085f5b8c0)),vocabulary(sha256('335c132fd0e3d3163ba40c255e7db41eecc36492d8098263c505b17f44bbef5a'))).
% S1: If a clinician works in a practice-context and the practice-context uses a toxicology-screening-panel and the toxicology-screening-panel includes a drug then the clinician should know the drug and should understand a toxicology-result-interpretation for the drug.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec10-imp09',1,box(1),[A,B,C,D,E,F,G]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'practice-context',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,work), guideline_arg(actual,C,1,A), guideline_pp(actual,C,in,B), guideline_entity(actual,D,'toxicology-screening-panel',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,use), guideline_arg(actual,E,1,B), guideline_arg(actual,E,2,D), guideline_entity(actual,F,drug,countable), guideline_cardinality(actual,F,na,eq,1), guideline_event(actual,G,include), guideline_arg(actual,G,1,D), guideline_arg(actual,G,2,F), \+ guideline_exclusion('cdc-2022-opioid').
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec10-imp09',1,box(1),[A,B,C,D,E,F,G]),'$guideline_id'(product,'cdc2022-opioid-rec10-imp09',1,ref(8),[A,B,C,D,E,F,G]),know) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'practice-context',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,work), guideline_arg(actual,C,1,A), guideline_pp(actual,C,in,B), guideline_entity(actual,D,'toxicology-screening-panel',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,use), guideline_arg(actual,E,1,B), guideline_arg(actual,E,2,D), guideline_entity(actual,F,drug,countable), guideline_cardinality(actual,F,na,eq,1), guideline_event(actual,G,include), guideline_arg(actual,G,1,D), guideline_arg(actual,G,2,F).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec10-imp09',1,box(1),[A,B,C,D,E,F,G]),'$guideline_id'(product,'cdc2022-opioid-rec10-imp09',1,ref(8),[A,B,C,D,E,F,G]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'practice-context',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,work), guideline_arg(actual,C,1,A), guideline_pp(actual,C,in,B), guideline_entity(actual,D,'toxicology-screening-panel',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,use), guideline_arg(actual,E,1,B), guideline_arg(actual,E,2,D), guideline_entity(actual,F,drug,countable), guideline_cardinality(actual,F,na,eq,1), guideline_event(actual,G,include), guideline_arg(actual,G,1,D), guideline_arg(actual,G,2,F).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec10-imp09',1,box(1),[A,B,C,D,E,F,G]),'$guideline_id'(product,'cdc2022-opioid-rec10-imp09',1,ref(8),[A,B,C,D,E,F,G]),2,F) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'practice-context',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,work), guideline_arg(actual,C,1,A), guideline_pp(actual,C,in,B), guideline_entity(actual,D,'toxicology-screening-panel',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,use), guideline_arg(actual,E,1,B), guideline_arg(actual,E,2,D), guideline_entity(actual,F,drug,countable), guideline_cardinality(actual,F,na,eq,1), guideline_event(actual,G,include), guideline_arg(actual,G,1,D), guideline_arg(actual,G,2,F).
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec10-imp09',1,box(2),[A,B,C,D,E,F,G]),should) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'practice-context',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,work), guideline_arg(actual,C,1,A), guideline_pp(actual,C,in,B), guideline_entity(actual,D,'toxicology-screening-panel',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,use), guideline_arg(actual,E,1,B), guideline_arg(actual,E,2,D), guideline_entity(actual,F,drug,countable), guideline_cardinality(actual,F,na,eq,1), guideline_event(actual,G,include), guideline_arg(actual,G,1,D), guideline_arg(actual,G,2,F), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec10-imp09',1,box(2),[A,B,C,D,E,F,G]),'$guideline_id'(product,'cdc2022-opioid-rec10-imp09',1,ref(9),[A,B,C,D,E,F,G]),'toxicology-result-interpretation',countable) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'practice-context',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,work), guideline_arg(actual,C,1,A), guideline_pp(actual,C,in,B), guideline_entity(actual,D,'toxicology-screening-panel',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,use), guideline_arg(actual,E,1,B), guideline_arg(actual,E,2,D), guideline_entity(actual,F,drug,countable), guideline_cardinality(actual,F,na,eq,1), guideline_event(actual,G,include), guideline_arg(actual,G,1,D), guideline_arg(actual,G,2,F).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec10-imp09',1,box(2),[A,B,C,D,E,F,G]),'$guideline_id'(product,'cdc2022-opioid-rec10-imp09',1,ref(9),[A,B,C,D,E,F,G]),na,eq,1) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'practice-context',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,work), guideline_arg(actual,C,1,A), guideline_pp(actual,C,in,B), guideline_entity(actual,D,'toxicology-screening-panel',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,use), guideline_arg(actual,E,1,B), guideline_arg(actual,E,2,D), guideline_entity(actual,F,drug,countable), guideline_cardinality(actual,F,na,eq,1), guideline_event(actual,G,include), guideline_arg(actual,G,1,D), guideline_arg(actual,G,2,F).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec10-imp09',1,box(2),[A,B,C,D,E,F,G]),'$guideline_id'(product,'cdc2022-opioid-rec10-imp09',1,ref(10),[A,B,C,D,E,F,G]),understand) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'practice-context',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,work), guideline_arg(actual,C,1,A), guideline_pp(actual,C,in,B), guideline_entity(actual,D,'toxicology-screening-panel',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,use), guideline_arg(actual,E,1,B), guideline_arg(actual,E,2,D), guideline_entity(actual,F,drug,countable), guideline_cardinality(actual,F,na,eq,1), guideline_event(actual,G,include), guideline_arg(actual,G,1,D), guideline_arg(actual,G,2,F).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec10-imp09',1,box(2),[A,B,C,D,E,F,G]),'$guideline_id'(product,'cdc2022-opioid-rec10-imp09',1,ref(10),[A,B,C,D,E,F,G]),1,A) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'practice-context',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,work), guideline_arg(actual,C,1,A), guideline_pp(actual,C,in,B), guideline_entity(actual,D,'toxicology-screening-panel',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,use), guideline_arg(actual,E,1,B), guideline_arg(actual,E,2,D), guideline_entity(actual,F,drug,countable), guideline_cardinality(actual,F,na,eq,1), guideline_event(actual,G,include), guideline_arg(actual,G,1,D), guideline_arg(actual,G,2,F).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec10-imp09',1,box(2),[A,B,C,D,E,F,G]),'$guideline_id'(product,'cdc2022-opioid-rec10-imp09',1,ref(10),[A,B,C,D,E,F,G]),2,'$guideline_id'(product,'cdc2022-opioid-rec10-imp09',1,ref(9),[A,B,C,D,E,F,G])) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'practice-context',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,work), guideline_arg(actual,C,1,A), guideline_pp(actual,C,in,B), guideline_entity(actual,D,'toxicology-screening-panel',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,use), guideline_arg(actual,E,1,B), guideline_arg(actual,E,2,D), guideline_entity(actual,F,drug,countable), guideline_cardinality(actual,F,na,eq,1), guideline_event(actual,G,include), guideline_arg(actual,G,1,D), guideline_arg(actual,G,2,F).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-rec10-imp09',1,box(2),[A,B,C,D,E,F,G]),'$guideline_id'(product,'cdc2022-opioid-rec10-imp09',1,ref(10),[A,B,C,D,E,F,G]),for,F) :- guideline_entity(actual,A,clinician,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'practice-context',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,C,work), guideline_arg(actual,C,1,A), guideline_pp(actual,C,in,B), guideline_entity(actual,D,'toxicology-screening-panel',countable), guideline_cardinality(actual,D,na,eq,1), guideline_event(actual,E,use), guideline_arg(actual,E,1,B), guideline_arg(actual,E,2,D), guideline_entity(actual,F,drug,countable), guideline_cardinality(actual,F,na,eq,1), guideline_event(actual,G,include), guideline_arg(actual,G,1,D), guideline_arg(actual,G,2,F).
