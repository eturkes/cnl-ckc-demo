% cdc2022-opioid-rec06.pl compiled from ACE by ace_to_pl; regenerate via ckc compile; do not edit.
:- multifile(guideline_schema_version/1).
:- discontiguous(guideline_schema_version/1).
:- multifile(guideline_document/4).
:- discontiguous(guideline_document/4).
:- multifile(guideline_entity/4).
:- discontiguous(guideline_entity/4).
:- multifile(guideline_cardinality/5).
:- discontiguous(guideline_cardinality/5).
:- multifile(guideline_event/3).
:- discontiguous(guideline_event/3).
:- multifile(guideline_arg/4).
:- discontiguous(guideline_arg/4).
:- multifile(guideline_pp/4).
:- discontiguous(guideline_pp/4).
:- multifile(guideline_property/4).
:- discontiguous(guideline_property/4).
:- multifile(guideline_operator/3).
:- discontiguous(guideline_operator/3).
:- multifile(guideline_interval/6).
:- discontiguous(guideline_interval/6).
:- multifile(guideline_recurrence/4).
:- discontiguous(guideline_recurrence/4).
:- multifile(guideline_frequency/5).
:- discontiguous(guideline_frequency/5).
:- multifile(guideline_order/4).
:- discontiguous(guideline_order/4).
:- multifile(guideline_recurrence_window/7).
:- discontiguous(guideline_recurrence_window/7).
:- multifile(guideline_range/3).
:- discontiguous(guideline_range/3).
:- multifile(guideline_grade/5).
:- discontiguous(guideline_grade/5).
:- multifile(guideline_preference/4).
:- discontiguous(guideline_preference/4).
:- multifile(guideline_qualifier/4).
:- discontiguous(guideline_qualifier/4).
:- multifile(guideline_unit/3).
:- discontiguous(guideline_unit/3).
:- multifile(guideline_exclusion/1).
:- discontiguous(guideline_exclusion/1).
:- multifile(guideline_supersession/4).
:- discontiguous(guideline_supersession/4).
:- multifile(guideline_evaluation_date/1).
:- discontiguous(guideline_evaluation_date/1).
guideline_schema_version(1).
guideline_document('cdc2022-opioid-rec06',ace_sha256('150307470d30833865af549c58374c71952acdb3ed0a327b15dcbaea67114254'),ulex(sha256(fba48e003101de64df33400ab2595fa7589360ac19f4c77ac3d17bd085f5b8c0)),vocabulary(sha256('335c132fd0e3d3163ba40c255e7db41eecc36492d8098263c505b17f44bbef5a'))).
% S1: A recommendation is a category-A-recommendation and is an evidence-type-4-recommendation.
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(1),[]),recommendation,countable).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(1),[]),na,eq,1).
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(2),[]),'category-A-recommendation',countable).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(2),[]),na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(3),[]),be).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(3),[]),1,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(1),[])).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(3),[]),2,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(2),[])).
guideline_grade(actual,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(1),[]),strength,strong,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(2),[])).
guideline_entity(actual,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(4),[]),'evidence-type-4-recommendation',countable).
guideline_cardinality(actual,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(4),[]),na,eq,1).
guideline_event(actual,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(5),[]),be).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(5),[]),1,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(1),[])).
guideline_arg(actual,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(5),[]),2,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(4),[])).
guideline_grade(actual,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(1),[]),evidence,very_low,'$guideline_id'(product,'cdc2022-opioid-rec06',1,ref(4),[])).
% S2: If an opioid is needed for an acute-pain then every clinician should limit an opioid-quantity for an expected-opioid-requiring-severe-pain-duration.
guideline_operator(actual,'$guideline_id'(context,'cdc2022-opioid-rec06',2,box(1),[A,B,C,D,E]),should) :- guideline_entity(actual,A,opioid,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'acute-pain',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,needed,pos), guideline_qualifier(actual,D,applicability,needed), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1), \+ guideline_exclusion('cdc-2022-opioid').
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec06',2,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-rec06',2,ref(6),[A,B,C,D,E]),'opioid-quantity',countable) :- guideline_entity(actual,A,opioid,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'acute-pain',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,needed,pos), guideline_qualifier(actual,D,applicability,needed), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec06',2,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-rec06',2,ref(6),[A,B,C,D,E]),na,eq,1) :- guideline_entity(actual,A,opioid,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'acute-pain',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,needed,pos), guideline_qualifier(actual,D,applicability,needed), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_entity('$guideline_id'(context,'cdc2022-opioid-rec06',2,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-rec06',2,ref(7),[A,B,C,D,E]),'expected-opioid-requiring-severe-pain-duration',countable) :- guideline_entity(actual,A,opioid,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'acute-pain',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,needed,pos), guideline_qualifier(actual,D,applicability,needed), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_cardinality('$guideline_id'(context,'cdc2022-opioid-rec06',2,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-rec06',2,ref(7),[A,B,C,D,E]),na,eq,1) :- guideline_entity(actual,A,opioid,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'acute-pain',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,needed,pos), guideline_qualifier(actual,D,applicability,needed), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_event('$guideline_id'(context,'cdc2022-opioid-rec06',2,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-rec06',2,ref(8),[A,B,C,D,E]),limit) :- guideline_entity(actual,A,opioid,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'acute-pain',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,needed,pos), guideline_qualifier(actual,D,applicability,needed), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec06',2,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-rec06',2,ref(8),[A,B,C,D,E]),1,E) :- guideline_entity(actual,A,opioid,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'acute-pain',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,needed,pos), guideline_qualifier(actual,D,applicability,needed), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_arg('$guideline_id'(context,'cdc2022-opioid-rec06',2,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-rec06',2,ref(8),[A,B,C,D,E]),2,'$guideline_id'(product,'cdc2022-opioid-rec06',2,ref(6),[A,B,C,D,E])) :- guideline_entity(actual,A,opioid,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'acute-pain',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,needed,pos), guideline_qualifier(actual,D,applicability,needed), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
guideline_pp('$guideline_id'(context,'cdc2022-opioid-rec06',2,box(1),[A,B,C,D,E]),'$guideline_id'(product,'cdc2022-opioid-rec06',2,ref(8),[A,B,C,D,E]),for,'$guideline_id'(product,'cdc2022-opioid-rec06',2,ref(7),[A,B,C,D,E])) :- guideline_entity(actual,A,opioid,countable), guideline_cardinality(actual,A,na,eq,1), guideline_entity(actual,B,'acute-pain',countable), guideline_cardinality(actual,B,na,eq,1), guideline_event(actual,D,be), guideline_arg(actual,D,1,A), guideline_arg(actual,D,2,C), guideline_property(actual,C,needed,pos), guideline_qualifier(actual,D,applicability,needed), guideline_pp(actual,D,for,B), guideline_entity(actual,E,clinician,countable), guideline_cardinality(actual,E,na,eq,1).
